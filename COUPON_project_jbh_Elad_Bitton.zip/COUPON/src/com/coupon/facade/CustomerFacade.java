package com.coupon.facade;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Logger;

import com.coupon.DBDAO.CouponDBDAO;
import com.coupon.DBDAO.CustomerCouponDBDAO;
import com.coupon.DBDAO.CustomerDBDAO;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.basic.Customer;
import com.coupon.connectionPool.ConnectionPool;
import com.coupon.dao.CouponDao;
import com.coupon.dao.CustomerCouponDao;
import com.coupon.dao.customersDAO;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.CustomerCouponException;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.CustomerLoginException;
import com.coupon.exceptions.CouponProjectException.activationException;
public class CustomerFacade implements CouponClientFacade {
	private long customerID;
	
	ConnectionPool CP;
	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(AdminFacade.class);

	public CustomerFacade(){}
	
	/**
	 * GET TYPE OF USER
	 */
	@Override
	public String getTypeOfUser() {
		return "CUSTOMER";
	}
	/**
	 * LOGIN METHOD
	 * @param name
	 * @param password
	 * @param typeOfUser
	 * @return
	 * @throws activationException 
	 * @throws CustomerException 
	 * @throws CouponException 
	 * @throws CouponProjectException
	 */
	public static CustomerFacade login(String name, String password, TypeOfUser typeOfUser) throws CustomerLoginException, CustomerException, activationException, CouponException {

		if (typeOfUser != TypeOfUser.CUSTOMER) {
			logger.debug("customer login failed mismitch clientType =" + typeOfUser);
		}
		customersDAO customerDAO = new CustomerDBDAO();
		if (!customerDAO.login(name, password)) {
			logger.debug("customer login failed name = " + name);
		}
		CustomerFacade facade = new CustomerFacade();
		Customer customer = new Customer();
		facade.customerID = customer.getID();
		return facade;
	}
	

	/**
	 * get customer method
	 * @throws activationException 
	 * @throws CustomerCouponException 
	 */
	public Customer getCustomer() throws CustomerException, activationException {
		customersDAO customerDAO = new CustomerDBDAO();
		Customer customer = customerDAO.getCustomerByID(customerID);
		if (null == customer) {
			logger.debug("customer dosnt exist anymore " + customerID);			
		}		
		return customer;
	}

	/**
	 * update customer method
	 * @param customer
	 * @param ID
	 * @throws CustomerException
	 * @throws activationException
	 * @throws CouponException 
	 */
	public void updateCustomer(Customer customer) throws CustomerException, activationException, CouponException{
customersDAO customerDAO = new CustomerDBDAO();
		
		if (customer.getID() != customerID ){
			logger.error("updateCustomer only the current customer may be modified : id = " + customer.getID() + " current id = " + customerID);
			throw new CouponException("only the current customer may be modified");
		}
		customerDAO.updateCustomer(customer);
	}	

	/**
	 * Purchase coupon method
	 * @param coup
	 * @throws CouponException 
	 * @throws SQLException 
	 * @throws CustomerException 
	 * @throws activationException 
	 */
	public void purcheseCoupon(Coupon coupon,CustomerDBDAO customer,CustomerCouponDBDAO custName) throws CouponException, activationException, CustomerException, SQLException{

		Customer customer1 = getCustomer();
		Collection<Coupon> coupons = customer1.getCoupons();
		if (coupons.contains(coupon)) {
			throw new CouponException("customer already owns coupon " + coupon.toString());
		}

		if (coupon.getAmount() == 0) {
			throw new CouponException("coupon sold out " + coupon.toString());
		}


		if(coupon.isExpired()) {
			throw new CouponException("not availabe anymore " + coupon.toString());
		}

		CustomerCouponDao customerCouponDao = new CustomerCouponDBDAO();
		CouponDao couponDao = new CouponDBDAO();
		coupon.setAmount(coupon.getAmount() - 1);
		couponDao.updateCoupon(coupon);
		customerCouponDao.addCustomerCoupon (customerID, coupon.getID());
	}
	public void purchaseCoupon(Coupon coupon) throws Exception {

		Customer customer = getCustomer();
		Collection<Coupon> coupons = customer.getCoupons();
		if (coupons.contains(coupon)) {
			throw new CouponException("customer already owns coupon " + coupon.toString());
		}

		if (coupon.getAmount() == 0) {
			throw new CouponException("coupon sold out " + coupon.toString());
		}

//		

		if(coupon.isExpired()) {
			throw new CouponException("not availabe anymore " + coupon.toString());
		}

		CouponDao couponDAO = new CouponDBDAO();
		CustomerCouponDao couponDao2 = new CustomerCouponDBDAO();
		coupon.setAmount(coupon.getAmount() - 1);
		couponDAO.updateCoupon(coupon);
		couponDao2.addCustomerCoupon(customerID, coupon.getID());
	}
	/**
	 * purchaseCoupon - a helper function  
	 * @param couponTitle the title of the coupon to be purchased
	 * @throws Exception 
	 */
	public void purchaseCoupon(String couponTitle) throws Exception {
		CouponDao couponDAO = new CouponDBDAO();
		for (Coupon coupon : couponDAO.getAllCoupon()) { // find a coupon with the requested title
			if (coupon.getTitle().equals(couponTitle)) {
				purchaseCoupon(coupon);
				return;
			}
		}
		throw new CouponException("Coupon with title " + couponTitle + " dose not exist");
	}

	/**
	 * get all purchased coupons by customers
	 * @return
	 * @throws SQLException 
	 * @throws activationException 
	 * @throws CustomerException 
	 */
	public ArrayList<Coupon> getAllPurchasedCoupons() throws CustomerException, activationException, SQLException{
		Customer customer1  = getCustomer();
		return customer1.getCoupons();
	}

	/**
	 * 
	 * @return all coupons that the customer can buy
	 * @throws Exception
	 */
	public Collection<Coupon> getPurchableCoupons() throws Exception {
		CouponDao couponDAO = new CouponDBDAO();
		Collection<Coupon> allCoupons= couponDAO.getAllCoupon();
		Collection<Coupon> purchableCoupons = new ArrayList<Coupon>();
		Collection<Coupon> purchasedCoupons = getAllPurchasedCoupons();
		for(Coupon coupon : allCoupons){
			if(coupon.getAmount()<1) 
				continue;

			if(coupon.isExpired())
				continue;
			if(purchasedCoupons.contains(coupon))   //contains uses the equals method of Coupon class that we wrote
				continue;
			
			purchableCoupons.add(coupon);
		}
		
		
		return purchableCoupons;
	}
	/**
	 * get all purchase coupons by type method
	 * @param ct
	 * @return
	 * @throws CouponProjectException 
	 * @throws SQLException 
	 */
	public ArrayList<Coupon> getAllPurchasedCouponsByType(CouponType type) throws SQLException, CouponProjectException{
		ArrayList<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllPurchasedCoupons()) {
			if (coupon.getType() == type)
				coupons.add(coupon);
		}
		return coupons;
	}

	/**
	 * get all purchase coupons by type
	 * @param customer
	 * @param price
	 * @return
	 * @throws SQLException 
	 * @throws CouponProjectException 
	 */
	public ArrayList<Coupon> getAllPurchasedCouponsByPrice(Customer customer) throws CouponProjectException, SQLException{
		ArrayList<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllPurchasedCoupons()) {
			if (coupon.getPrice() <= coupon.getPrice())
				coupons.add(coupon);
		}

		return coupons;
	}


	/**
	 * 
	 * @param toDate
	 * @return all coupons that the customer can buy where endDate < toDate
	 * @throws Exception
	 */
	public Collection<Coupon> getPurchableCouponsByDate(LocalDate toDate) throws Exception {
		Collection<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getPurchableCoupons()) {
			if (coupon.getEndDate().isBefore(toDate))
				coupons.add(coupon);
		}

		return coupons;
	}	
	/**
	 * 
	 * @param toDate
	 * @return the coupons of the logedin customer where endDate < toDate
	 * @throws Exception
	 */
	public Collection<Coupon> getAllPurchasedCouponsByDate(LocalDate toDate) throws Exception {
		Collection<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllPurchasedCoupons()) {
			if (coupon.getEndDate().isBefore(toDate))
				coupons.add(coupon);
		}

		return coupons;
	}	
	/**
	 * get purchase coupon by title
	 * @param coupon2
	 * @throws Exception 
	 */
	public void purchaseCouponByTitle(Coupon coupon) throws Exception {
		CouponDao couponDAO = new CouponDBDAO();
		for (Coupon coupon1 : couponDAO.getAllCoupon()) { 
			if (coupon1.getTitle().equals(coupon1)) {
				purchaseCoupon(coupon1.getTitle());
				return ;
			}
		}
		logger.debug("Coupon with title dose not exist");
	}
	
}


