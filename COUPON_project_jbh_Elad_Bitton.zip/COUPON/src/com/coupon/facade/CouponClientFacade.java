package com.coupon.facade;

public interface  CouponClientFacade {

	public String getTypeOfUser();


}
