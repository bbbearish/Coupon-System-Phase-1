package com.coupon.facade;

public enum TypeOfUser {
	
  /**ENUM FOR ADMIN/Company/Customers*/
	   ADMIN,COMPANY,CUSTOMER , NoLoginUser;
}
