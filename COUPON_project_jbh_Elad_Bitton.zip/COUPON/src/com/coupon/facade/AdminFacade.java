package com.coupon.facade;


import java.sql.SQLException;
import java.util.Collection;
import javax.security.auth.login.LoginException;

import org.apache.log4j.Logger;

import com.coupon.DBDAO.CompanyCouponDBDAO;
import com.coupon.DBDAO.CompanyDBDAO;

import com.coupon.DBDAO.CustomerDBDAO;
import com.coupon.basic.Company;
import com.coupon.basic.Customer;


import com.coupon.dao.CompanyDAO;

import com.coupon.dao.customersDAO;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.*;

public class AdminFacade implements CouponClientFacade{

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(AdminFacade.class);
	/**
	 * constructor
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws CustomerException 
	 * @throws CouponException 
	 */
	public AdminFacade(){}
	/**
	 * TYPE OF USER 
	 */
	@Override
	public String getTypeOfUser(){
		return "ADMIN".toLowerCase();
	}
	/**
	 * login method
	 * @param username
	 * @param password
	 * @return
	 * @throws activationException 
	 * @throws LoginException
	 */
	@SuppressWarnings("static-access")
	public static CouponClientFacade login (String user ,String password, TypeOfUser typeOfUser) throws AdminLoginException{
		String rightPassword = "1234";

		if (typeOfUser != typeOfUser.ADMIN) {
			logger.error("admin login failed mismitch clientType = " + typeOfUser);
			throw new AdminLoginException("Invalid ClientType : " + typeOfUser);
		}

		if (typeOfUser == typeOfUser.ADMIN && "admin".equals(user) && rightPassword.equals(password))
		{
			return new AdminFacade();
		}

		logger.error("admin login failed name = " + user);
		throw new AdminLoginException(user);		
	}
	/**
	 * create company method
	 * @param company
	 * @throws com.coupon.exceptions.CouponProjectException.LoginException 
	 * @throws CompanyException 
	 * @throws activationException 
	 */
	public void createCompany(Company company) throws CompanyException, activationException, com.coupon.exceptions.CouponProjectException.LoginException  {
		CompanyDAO companyDAO = new CompanyDBDAO();
		String name = company.getCompName();
		if  (null != (companyDAO.getCompanyByName(name))){
			throw new CouponProjectException.LoginException("YOUR EMAIL ALLREDY EXIST");
		}
		try {
			companyDAO.createCompany(company);
		} catch (CompanyException e) {
			logger.debug(company+toString());
		} catch (activationException e) {
			logger.debug(company+toString());
		}
	}


	/**
	 * remove company coupon method
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws CouponException 
	 * @throws CustomerException 
	 */
	public void RemoveCompanyByID(long companyID) throws CouponException, activationException, CompanyException, CustomerException  {
		CompanyDAO companyDAO = new CompanyDBDAO();
		companyDAO.removeCompany(companyID);
	}	
	public void removeCompany(Company company) throws CompanyException, CouponException, activationException, CustomerException	{
		RemoveCompanyByID(company.getID());
	}

	/**
	 * update company method
	 * @param company
	 * @throws CouponException 
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 */
	public void updateCompany(Company company) throws CompanyException, activationException, SQLException {
		CompanyDAO companyDAO = new CompanyDBDAO();
		try {
			companyDAO.updateCompany(company);
		} catch (CompanyException e) {
			logger.error("updateCompany failed " + e.toString());
			throw e;
		}
	}

	/**
	 * get all companies method
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 */
	public Collection<Company> getAllCompanys() throws CompanyException, activationException {
		CompanyDAO compDao = new CompanyDBDAO();
		try {
			compDao.getAllCompanys();
		} catch (CompanyException e) {
			logger.debug(toString());
		} catch (activationException e) {			
			logger.debug(toString());
		}
		return compDao.getAllCompanys();
	}
	/**
	 * get company by ID method
	 * @param ID
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 */
	public Company getCompanyByID(long ID) throws CompanyException, activationException{
		CompanyDAO compDao = new CompanyDBDAO();
		return compDao.getCompanyByID(ID);
	}
	/**
	 * get company by name
	 * @param name
	 * @throws CompanyException
	 * @throws activationException
	 */
	public Company getCompanyByName(String name) throws CompanyException, activationException{
		CompanyDAO companyDAO = new CompanyDBDAO();
		return companyDAO.getCompanyByName(name);
	}
	/**
	 * create customer method
	 * @param cust
	 * @throws CustomerException 
	 * @throws activationException 
	 */
	public void createCustomer(Customer customer) throws CustomerException, activationException{
		customersDAO customerDAO = new CustomerDBDAO();
		String name = customer.getCustName();
		if (null != customerDAO.getCustomerByName(name)) {
			logger.error("createCustomer " + name + " already exists");
			throw new CustomerException("createCustomer " + name + " already exists");			
		}
		try {
			customerDAO.createCustomer(customer);
		} catch (Exception e) {
			logger.error("createCustomer failed : " + e.toString());
			throw e;
		}
	}
	/**
	 * remove customer method
	 * @param ID
	 * @param ID
	 * @throws CustomerException
	 * @throws activationException
	 */
	public void removeCustomer(long ID) throws CustomerException, activationException{
		customersDAO customersDAO = new CustomerDBDAO();
		customersDAO.removeCustomer(ID);
	}

	public void removeCustomer(Customer customer) throws Exception {
		removeCustomer(customer.getID());
	}	
	/**
	 * update customer method
	 * @param customer
	 * @param ID
	 * @throws CustomerException
	 * @throws activationException
	 */
	public void updateCustomer(Customer customer) throws CustomerException, activationException{
		customersDAO customerDAO = new CustomerDBDAO();
		try {
			customerDAO.updateCustomer(customer);
		} catch (Exception e) {
			logger.error("updateCustomer " + customer.getCustName() + " failed : " + e.toString());
			throw e;
		}
	}
	
	/**
	 * get customer by ID method
	 * @param ID
	 * @return
	 * @throws CustomerException
	 * @throws activationException
	 */
	public Customer getCustomerById(Long ID) throws CustomerException, activationException{
		customersDAO customersDAO = new CustomerDBDAO();

		return customersDAO.getCustomerByID(ID);
	}
	/**
	 * get customer by NAME method
	 * @param name
	 * @return
	 * @throws CustomerException
	 * @throws activationException
	 */
	public Customer getCustomerByName(String name) throws CustomerException, activationException{
		customersDAO customersDAO = new CustomerDBDAO();

		return customersDAO.getCustomerByName(name);
	}
	/**
	 * get all customers method
	 * @return
	 * @throws CustomerException
	 * @throws activationException
	 */
	public Collection<Customer> getAllCustomers() throws CustomerException, activationException{
		customersDAO customersDAO = new CustomerDBDAO();

		return customersDAO.getAllCustomer();
	}



	/**
	 * remove company coupon method
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws CouponException 
	 */
	public Company RemoveCompanyCoupon(long compID) throws CompanyException, activationException, CouponException  {
		CompanyCouponDBDAO companyCouponDBDAO = new CompanyCouponDBDAO();
		try{
			companyCouponDBDAO.removeCompanyCoupon(compID);
		} catch (CompanyException e) {
			logger.debug("check remove company faced method" + e.toString());
		} catch (activationException e) {
			logger.debug("check your login "+e.toString());
		}
		return RemoveCompanyCoupon(compID);
	}

}


