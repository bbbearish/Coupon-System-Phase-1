package com.coupon.facade;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import org.apache.log4j.Logger;

import com.coupon.DBDAO.CompanyCouponDBDAO;
import com.coupon.DBDAO.CompanyDBDAO;
import com.coupon.DBDAO.CouponDBDAO;
import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.connectionPool.ConnectionPool;
import com.coupon.dao.CompanyCoponDao;
import com.coupon.dao.CompanyDAO;
import com.coupon.dao.CouponDao;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CompanyLoginException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;


public class CompanyFacade implements CouponClientFacade {

	private long companyID;

	ConnectionPool CP;

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CompanyFacade.class);

	public CompanyFacade(){}


	/**
	 * LOGIN METHOD
	 * @throws CompanyException 
	 * @throws activationException 
	 */
	@Override
	public String getTypeOfUser(){
		return "COMPANY";
	}

	private Connection getConnection() throws Exception {
		try {
			ConnectionPool pool = ConnectionPool.getInstance();
			Connection conn = pool.getConnection();
			return conn;
		} catch (Exception e) {
			logger.error("getConnection failed : " + e.toString());
			throw e;
		}
	}

	private void returnConnection(Connection conn) {
		try {
			ConnectionPool pool = ConnectionPool.getInstance();
			pool.returnConnection(conn);
		} catch (Exception e) {
			logger.error("returnConnection failed : " + e.toString());
		}
	}
	/**
	 * login method
	 * @param name
	 * @param password
	 * @param typeOfUser
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws CompanyLoginException 
	 * @throws CouponException 
	 */
	public static CompanyFacade login(String email, String password, TypeOfUser typeOfUser) throws CompanyLoginException, CompanyException, activationException, CouponException {

		if (typeOfUser != TypeOfUser.COMPANY) {
			logger.debug ("company login failed mismitch clientType =" + typeOfUser);
		}
		CompanyDAO companyDAO = new CompanyDBDAO();
		if (!(companyDAO.login(email, password))) {
			logger.debug("customer login failed name = " + email);
		}
		CompanyFacade facade = new CompanyFacade();
		Company company = new Company();
		facade.companyID = company.getID();
		return facade;
	}

	/**
	 * update company method
	 * @param company
	 * @throws CouponException 
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 */
	public void updateCompany(Company company) throws CouponException, CompanyException, activationException, SQLException{
		CompanyDAO companyDAO = new CompanyDBDAO();

		if (company.getID() != companyID ){
			logger.error("updateCompany only the current company may be modified : id = " + company.getID() + " current id = " + companyID);
			throw new CouponException("only the current company may be modified");
		}
		companyDAO.updateCompany(company);
	}	

	/**
	 * create new coupon by company
	 * @param coup
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public void createCoupon( Coupon coupon) throws CouponException, activationException, CompanyException, SQLException{
		CouponDao couponDao = new CouponDBDAO();
		couponDao.createCoupon(coupon);
	}
	public void addCompanyCouponByID(long companyID,long couponID) throws CompanyException, activationException, CouponException, SQLException {
		CompanyCoponDao companyCoponDao = new CompanyCouponDBDAO();
		companyCoponDao.addCompanyCoupon(companyID, couponID);
	}
	/**
	 * remove coupon by company 
	 * @param coup
	 * @throws CouponException 
	 * @throws SQLException 
	 * @throws activationException 
	 */

	public void removeCoupon(long couponId) throws Exception {
		if (!companyHasCoupon(couponId)) {
			throw new CouponException("company " +  couponId + " does not own coupon " + couponId);
		}

		Connection conn = getConnection();
		CouponDao couponDAO = new CouponDBDAO();

		try {
			conn.setAutoCommit(false); // begin transaction

			//couponDAO.removeCoupon(coupon); 
			couponDAO.removeCoupon(couponId);

			conn.commit(); // end the transaction
		} catch (Exception e) {
			logger.error("removeCoupon failed : " + e.toString());
			try {
				conn.rollback(); // abort the transaction
			} catch (SQLException e1) {
				logger.error("removeCoupon rollback failed : " + e.toString());
			}
			throw e;
		} finally {
			returnConnection(conn);
		}
	}


	public void removeCoupon(Coupon coupon) throws Exception {
		removeCoupon(coupon.getID());
	}


	/**
	 * update coupon method
	 * @param coup
	 * @throws CouponException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 * @throws activationException 
	 */
	public void updateCoupon(Coupon coupon) throws Exception {
		if (!companyHasCoupon(coupon.getID())) {
			throw new CouponException("company " +  companyID + " does not own coupon " + coupon.getID());
		}

		CouponDao couponDAO = new CouponDBDAO();
		try {
			couponDAO.updateCoupon(coupon);
		} catch (Exception e) {
			logger.error("update coupon failed : " + e.toString());
			throw e;
		}

	}

	/**
	 * get coupons by id 
	 * @param couponID
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 * @throws Exception 
	 */
	public Coupon getCouponByID(long couponID) throws CouponException, CompanyException, activationException, SQLException {
		for (Coupon coupon : getAllCoupons()) { 
			if (coupon.getID() == couponID)
				return coupon;
		}
		return null;		
	}
	/**
	 * get all coupons 
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 * @throws Exception
	 */
	public Collection<Coupon> getAllCoupons() throws CouponException, CompanyException, activationException, SQLException{
		CouponDao companyDBDAO = new CouponDBDAO();
		return companyDBDAO.getAllCoupon();
	}
	/**
	 * get coupon by type method
	 * @param ct
	 * @return
	 * @throws CouponProjectException 
	 * @throws SQLException 
	 */
	public Collection<Coupon>getCouponByType(CouponType CouponType) throws SQLException, CouponProjectException{
		CouponDao coupDao = new CouponDBDAO();
		return coupDao.getCopounByType(CouponType);
	}

	public CouponType[] getCouponTypes() {
		return CouponType.values();
	}


	/**
	 * return coupons by date 
	 * @param date
	 * @return
	 * @throws CouponException
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 */
	public Collection<Coupon> getCouponsByDate(LocalDate date) throws CouponException, CompanyException, activationException, SQLException {
		Collection<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllCoupons()) {
			if (coupon.getEndDate().isBefore(date))
				coupons.add(coupon);
		}
		return coupons;
	}
	/**
	 * 
	 * @param type
	 * @return the coupons of the logedin company of a specific type 
	 * @throws Exception
	 */
	public Collection<Coupon> getCouponsByType(CouponType type) throws Exception {
		Collection<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllCoupons()) {
			if (coupon.getType() == type)
				coupons.add(coupon);
		}

		return coupons;
	}

	/**
	 * get company coupons by price
	 * @param price
	 * @return
	 * @throws CouponException
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 */
	public Collection<Coupon> getCouponsByPrice(double price) throws CouponException, CompanyException, activationException, SQLException {
		Collection<Coupon> coupons = new ArrayList<Coupon>();
		for (Coupon coupon : getAllCoupons()) {
			if (coupon.getPrice() <= price)
				coupons.add(coupon);
		}
		return coupons;
	}
	/**
	 * 
	 * @return the currently login Company 
	 * @throws activationException 
	 * @throws CompanyException 
	 */
	public Company getCompany() throws CompanyException, activationException {
		CompanyDAO companyDAO = new CompanyDBDAO();
		Company company = companyDAO.getCompanyByID(companyID);
		if (null == company) {
			logger.error("getCompany company does not exist any more : id = " + companyID);

		}
		return company;
	}
	/**
	 * check if  the coupon title  exist
	 * @param title
	 * @return
	 * @throws CouponException 
	 * @throws CompanyException
	 * @throws activationException 
	 * @throws SQLException 
	 */
	@SuppressWarnings("unused")
	private boolean companyHasCoupon(String title) throws CompanyException, CouponException, activationException, SQLException {
		for (Coupon coupon : getAllCoupons()) { 
			if (coupon.getTitle().equals(title))
				return true;
		}
		return false;
	}
	/**
	 * check if  the coupon ID  exist
	 * @param title
	 * @return
	 * @throws CouponException 
	 * @throws CompanyException
	 * @throws activationException 
	 */
	private boolean companyHasCoupon(long couponId) throws Exception {
		for (Coupon coupon : getAllCoupons()) { // check all coupons of the current (logedin) company 
			if (coupon.getID() == couponId)
				return true;
		}
		return false;
	}

}