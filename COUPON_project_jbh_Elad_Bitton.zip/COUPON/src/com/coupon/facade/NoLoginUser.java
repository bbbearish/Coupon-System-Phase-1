package com.coupon.facade;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Logger;

import com.coupon.DBDAO.CompanyDBDAO;
import com.coupon.DBDAO.CouponDBDAO;
import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.dao.CompanyDAO;
import com.coupon.dao.CouponDao;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;

public class NoLoginUser {

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(AdminFacade.class);
	public NoLoginUser(){}

	/**
	 * get all companies method
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 */
	public Collection<Company> getAllCompanys() throws CompanyException, activationException {
		CompanyDAO compDao = new CompanyDBDAO();
		try {
			compDao.getAllCompanys();
		} catch (CompanyException e) {
			logger.debug(toString());
		} catch (activationException e) {			
			logger.debug(toString());
		}
		return compDao.getAllCompanys();
	}
	/**
	 * get company by ID method
	 * @param ID
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 */
	public Company getCompanyByID(long ID) throws CompanyException, activationException{
		CompanyDAO compDao = new CompanyDBDAO();
		return compDao.getCompanyByID(ID);
	}
	/**
	 * get company by name
	 * @param name
	 * @throws CompanyException
	 * @throws activationException
	 */
	public Company getCompanyByName(String name) throws CompanyException, activationException{
		CompanyDAO companyDAO = new CompanyDBDAO();
		return companyDAO.getCompanyByName(name);
	}
	/**
	 * get all coupons 
	 * @return
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 * @throws Exception
	 */
	public Collection<Coupon> getAllCoupons() throws CouponException, CompanyException, activationException, SQLException{
		CouponDao companyDBDAO = new CouponDBDAO();
		return companyDBDAO.getAllCoupon();
	}
	/**
	 * get coupon by type method
	 * @param ct
	 * @return
	 * @throws CouponProjectException 
	 * @throws SQLException 
	 */
	public Collection<Coupon>getCouponByType(CouponType CouponType) throws SQLException, CouponProjectException{
		CouponDao coupDao = new CouponDBDAO();
		return coupDao.getCopounByType(CouponType);
	}

	public CouponType[] getCouponTypes() {
		return CouponType.values();
	}


	/**
	 * return coupons by date 
	 * @param date
	 * @return
	 * @throws CouponException
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 */
	public Collection<Coupon> getCouponsByDate(LocalDate date) throws CouponException, CompanyException, activationException, SQLException {
		Collection<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllCoupons()) {
			if (coupon.getEndDate().isBefore(date))
				coupons.add(coupon);
		}
		return coupons;
	}
	/**
	 * 
	 * @param type
	 * @return the coupons of the logedin company of a specific type 
	 * @throws Exception
	 */
	public Collection<Coupon> getCouponsByType(CouponType type) throws Exception {
		Collection<Coupon> coupons = new ArrayList<Coupon>();

		for (Coupon coupon : getAllCoupons()) {
			if (coupon.getType() == type)
				coupons.add(coupon);
		}

		return coupons;
	}

	/**
	 * get company coupons by price
	 * @param price
	 * @return
	 * @throws CouponException
	 * @throws activationException 
	 * @throws CompanyException 
	 * @throws SQLException 
	 */
	public Collection<Coupon> getCouponsByPrice(double price) throws CouponException, CompanyException, activationException, SQLException {
		Collection<Coupon> coupons = new ArrayList<Coupon>();
		for (Coupon coupon : getAllCoupons()) {
			if (coupon.getPrice() <= price)
				coupons.add(coupon);
		}
		return coupons;
	}
}
