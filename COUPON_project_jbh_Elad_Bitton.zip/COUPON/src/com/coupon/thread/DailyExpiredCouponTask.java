package com.coupon.thread;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.apache.log4j.Logger;
import com.coupon.DBDAO.CompanyDBDAO;
import com.coupon.basic.Coupon;
import com.coupon.dao.CouponDao;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;



public class DailyExpiredCouponTask extends Thread  {
	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CompanyDBDAO.class);

	private CouponDao DAO;
	private boolean quit;
	/**
	 * constructor
	 * @throws CouponException
	 * @throws activationException
	 */
	public DailyExpiredCouponTask() throws CouponException, activationException{
		super();
	}
	/**
	 * run the daily expired method
	 */
	public void run() {
		Set<Coupon> remove = new HashSet<>();
		activationException cm = new activationException("connection ishu");

		try {
			while(!quit){ 
				System.out.println("woke up");
				ArrayList<Coupon> coupons = DAO.getAllCoupon();
				for (Coupon coupon : coupons) {
					if(coupon.getEndDate().isBefore(LocalDate.now())){
						remove.add(coupon);
						long ID = 0;
						DAO.removeCoupon(ID);
						System.out.println("the coupons : \n"+remove +" successfuly remove");
					}
				}
				System.out.println("went sleeping");
				Thread.sleep(5000);

			}
		}catch (activationException e) {
			try {
				cm.ConnectionInUse();
			} catch (CouponProjectException d2) {
				logger.debug(d2.toString());					}
		} catch (CouponException e) {
			logger.debug(e.toString());				
		} catch (SQLException e) {
			logger.debug(e.toString());				
		} catch (InterruptedException e) {
			logger.debug(e.toString());		
		} 
	}
	/**
	 * stop task method
	 */
	public void stopTask(){
		if (!quit) {
			logger.info("the task stop");
			quit = true;
		} else {
			logger.info("DailyCouponExpirationTask stopped");
		}
	}
	/**
	 * 
	 * @param sleepTime
	 */
	public void setSleepTime(long sleepTime) {
		logger.info("setSleepTime " + sleepTime);
	}

}