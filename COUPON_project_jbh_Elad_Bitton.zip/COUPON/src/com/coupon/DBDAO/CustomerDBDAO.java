package com.coupon.DBDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.coupon.basic.Customer;
import com.coupon.connectionPool.ConnectionPool;

import com.coupon.dao.customersDAO;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.*;


public class CustomerDBDAO   implements customersDAO{
	/**
	 * Creating tools from imported java.sql classes to work with database:*
	 */
	Connection myConn;
	PreparedStatement myPstat;
	Statement myStat;
	ResultSet myRset;
	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CustomerCouponDBDAO.class);
	/**
	 * getting an instance of a connection from the ConnectionPool:
	 */
	ConnectionPool CP;
	public CustomerDBDAO() throws CustomerException, activationException{
		CP =  ConnectionPool.getInstance();
	}
	/**
	 * CREATE CUSTOMER METHOD
	 * @throws activationException 
	 * @throws CouponProjectException 
	 */
	@Override
	public void createCustomer(Customer customer) throws CustomerException, activationException {
		try {
			myConn = CP.getConnection();
			myPstat = myConn.prepareStatement("INSERT INTO customer (CUSTOMER_NAME, PASSWORD, EMAIL)  VALUES(?,?,?)",
					Statement.RETURN_GENERATED_KEYS);

			myPstat.setString(1, customer.getCustName());
			myPstat.setString(2, customer.getEmail());
			myPstat.setString(3, customer.getPassword());
			myPstat.executeUpdate();

			myRset = myPstat.getGeneratedKeys();

			if (myRset != null && myRset.next()) {
				Long key = myRset.getLong(1);
				customer.setID(key); 
			}
			System.out.println("THE CUSTOMER "+customer.getCustName()+" create successfuly");

		} catch (SQLException | CouponProjectException e) {
			logger.debug			("CREATE CUSTOMER FAILED...");
		} finally {
			CP.returnConnection(myConn);
		}
	}
	/**
	 * REMOVE CUSTOMER
	 */
	@Override
	public void removeCustomer(long ID) throws CustomerException, activationException  {
		myConn= CP.getConnection();
		CustomerCouponDBDAO customerCouponDBDAO = new CustomerCouponDBDAO();
		boolean booliTransaction = false;
		try {
			booliTransaction = myConn.getAutoCommit(); 
			if (booliTransaction)myConn.setAutoCommit(false);
			customerCouponDBDAO.removeCustomerCoupon(ID);
			String DB = "delete from customer where ID=?";
			myPstat = myConn.prepareStatement(DB);
			myPstat.setLong(1, ID);

			int rowsLeftToCheck = myPstat.executeUpdate();
			if (rowsLeftToCheck == 0) {
				throw new SQLException("removeCustomer id failed");
			}				

			if (booliTransaction)
				myConn.commit(); 
			System.out.println("REMOVE SUCCESS");
		} catch (SQLException e) {
			logger.debug("removeCompany failed : " + e.toString());		

		} finally {
			CP.returnConnection(myConn);
		}

	}
	/**
	 * UPDATE CUSTOMER
	 */

	@Override
	public void updateCustomer(Customer customer) throws CustomerException, activationException  {

		try {
			myConn = CP.getConnection();
			myPstat = myConn.prepareStatement
					("UPDATE customer CUSTOMER_NAME = ?,EMAIL = ?, PASSWORD = ? WHERE ID = ?");
			myPstat.setLong(1, customer.getID());
			myPstat.setString(2, customer.getCustName());
			myPstat.setString(3, customer.getEmail());
			myPstat.setString(4, customer.getPassword());
			myPstat.executeUpdate();
			
			System.out.println("update customer "+ customer.getCustName()+" success");
		} catch (SQLException e) {
			logger.debug			("update customer failed");
		}  finally {
			CP.returnConnection(myConn);
		}
	}
	/**
	 * GET ALL CUSTOMERS
	 */
	@Override
	public HashSet<Customer> getAllCustomer() throws CustomerException , activationException {
		Set<Customer> customer = new HashSet<>();
		Set<Long> ID=new HashSet<>();
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myRset = myStat.executeQuery("SELECT ID FROM customer");

			while (myRset.next()) {
				ID.add(myRset.getLong(1));
			}
			for(Long l:ID){
				customer.add(this.getCustomerByID(l));
			}
		} catch (SQLException e) {
			logger.debug("there is a problem in the connection to the database.");
		} finally {
			CP.returnConnection(myConn);
		}
		return (HashSet<Customer>) customer;
	}
	/**
	 * GET CUSTOMER BY NAME
	 */
	@Override
	public Customer getCustomerByName(String name) throws CustomerException, activationException {
		Customer customer = null;
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			ResultSet myResultSet = myStat.executeQuery("SELECT * FROM customer WHERE CUST_NAME = '"+name+"'");
			if(myResultSet.next()){
				customer = new Customer(
						myResultSet.getString("CUST_NAME"), 
						myResultSet.getString("PASSWORD"),
						myResultSet.getString("EMAIL"));
			}else {
				logger.debug("There was no Customer found with the name '"+name+"' in the database");
			}			
		} catch (SQLException | CouponProjectException e) {
			logger.debug("there is a problem in the connection to the database.");
		}finally {
			CP.returnConnection(myConn);
		}
		return customer;

	}
	/**
	 * GET CUSTOMER BY ID
	 */
	@Override
	public Customer getCustomerByID(long ID) throws CustomerException , activationException {
		Customer customer = null;
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myRset  = myStat.executeQuery("SELECT * FROM customer WHERE ID = "+ID+"");
			if(myRset.next()){
				customer = new Customer(
						myRset.getString("custName"), 
						myRset.getString("password"),
						myRset.getString("email"));

			}else {
				if(ID!=0){
					logger.debug					("THE CUSTOMER ID: #"+ID+" NOT FOUND IN THE DB ");
				}else{
					logger.debug					("THERE IS NO CUSTOMER WITH THAT ID IN THE DB ");
				}
			}
		} catch (SQLException | CouponProjectException e) {
			logger.debug			("CONNECTION FAILD...CHECK AGAIN!!!");			
		}  finally {
			CP.returnConnection(myConn);
		}
		return customer;

	}
	/**
	 * LOGIN METHOD
	 */
	@Override
	public boolean login(String custName, String password)throws CustomerException, activationException  {
		ResultSet rs;
		try{
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			rs = myStat.executeQuery
					("SELECT PASSWORD FROM customer WHERE CUSTOMER_NAME = '"+custName+"'");
			if (rs.next()) 
				if(password.equals(rs.getString(1)))
					return true; 
				else
					throw new CustomerException("PASSWORD WRONG...CHECK AGAIN");
			else
				logger.debug				("WRONG DETAILS...CHECK AGAIN PLEASE");
		} catch (SQLException e) {
			logger.debug			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);			
		}
		return false;
	}
	/**
	 * CHECK FOR DUPLICATES 
	 * @param custName
	 * @return
	 * @throws companyExcepsions
	 */
	@Override
	public boolean isCustomer(long ID) throws CustomerException , activationException {
		boolean isCustomer = false;
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement			
					("Select * FROM customer WHERE ID=" + ID);
			myRset= myPstat.executeQuery();
			if(myRset.next()){
				isCustomer = true;
			}
		}catch(SQLException e){
			logger.debug			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return isCustomer;
	}
	/**
	 * CHECK DUPLICATE EMAIL
	 */
	@Override
	public boolean isCustomerEmail(String Email) throws CustomerException , activationException{
		boolean isCustomerEmail = false;
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement			
					("Select * FROM customer WHERE EMAIL=" + Email);
			myRset= myPstat.executeQuery();
			if(myRset.next()){
				isCustomerEmail = true;
			}
		}catch(SQLException e){
			logger.debug			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return isCustomerEmail;
	}
	/**
	 * another help method to use in this class to update parameters
	 * @param DB
	 * @param ID
	 * @throws SQLException
	 * @throws activationException 
	 */
	@SuppressWarnings("unused")
	private void Updator(String DB, long ID) throws SQLException, activationException {
		myConn= CP.getConnection();
		try {
			myPstat = myConn.prepareStatement(DB);
			myPstat.setLong(1, ID);
			myPstat.executeUpdate();
		} catch (SQLException e) {
			logger.debug(e.toString());
		} finally {
			CP.returnConnection(myConn);
		}

	}


}



