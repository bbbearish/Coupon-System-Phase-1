package com.coupon.DBDAO;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;

import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.basic.Customer;
import com.coupon.connectionPool.ConnectionPool;

import com.coupon.dao.CouponDao;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;

/**
 * TOOLS FOR TO WORK WITH THE DB FROM JAVA
 */
public class CouponDBDAO  implements CouponDao {
	Connection myConn;
	PreparedStatement myPstat;
	ResultSet myRset;
	/**
	 * GETTING INSTANCE CONNECTION FROM CONNECTIONPOOL CLASS
	 */
	ConnectionPool CP;
	public CouponDBDAO() throws CouponException, activationException{		
		CP=ConnectionPool.getInstance();
	}

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CouponDBDAO.class);
	/**
	 * 
	 * @param myResultSet
	 * @return FOR METHODS THAT WANT TO READ FROM THE DB 
	 * @throws SQLException
	 * @throws CouponException
	 */
	@Override
	public Coupon getFromResultSet(ResultSet myRset) throws SQLException, CouponException {
		Coupon coupon = new Coupon();
		coupon.setID(myRset.getLong("ID"));
		coupon.setTitle(myRset.getString("TITLE"));
		coupon.setAmount(myRset.getInt("AMOUNT"));
		coupon.setStartDate(myRset.getDate("START_DATE").toLocalDate());
		coupon.setStartTime(myRset.getTime("START_TIME").toLocalTime());
		coupon.setEndDate(myRset.getDate("END_DATE").toLocalDate());
		coupon.setEndTime(myRset.getTime("END_TIME").toLocalTime());
		coupon.setImage(myRset.getString("IMAGE"));
		coupon.setMessage(myRset.getString("MESSAGE"));
		coupon.setPrice(myRset.getDouble("PRICE"));
		String couponType = myRset.getString("TYPE");
		coupon.setCouponType(CouponType.valueOf(couponType));
		return coupon;
	}

	/**
	 * CREATE COUPON
	 * @throws activationException 
	 * @throws Throwable 
	 * 
	 * */
	@Override
	public void createCoupon(Coupon coupon) throws CouponException, SQLException, activationException {
		try {
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT TITLE FROM coupon ");
			myRset = myPstat.executeQuery();
			while (myRset.next()) {
				if(coupon.getTitle().equals(myRset.getString("title"))){
					throw new CouponException("the coupon title allredy exist");
				}
			}

			myPstat = myConn.prepareStatement
					("INSERT INTO coupon (TITLE,START_DATE,START_TIME,END_DATE,END_TIME,AMOUNT,TYPE,MESSAGE,PRICE,IMAGE )"
							+" VALUES (?,?,?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);

			myPstat.setString(1,coupon.getTitle());
			myPstat.setDate(2,java.sql.Date.valueOf( coupon.getStartDate()));
			myPstat.setTime(3,java.sql.Time.valueOf( coupon.getStartTime()));
			myPstat.setDate(4, java.sql.Date.valueOf(coupon.getEndDate()));
			myPstat.setTime(5,java.sql.Time.valueOf( coupon.getEndTime()));
			myPstat.setInt(6, coupon.getAmount());
			myPstat.setString(7, coupon.getType().name());
			myPstat.setString(8, coupon.getMessage());
			myPstat.setDouble(9, coupon.getPrice());
			myPstat.setString(10, coupon.getImage());
			myPstat.executeUpdate();
			myRset = myPstat.getGeneratedKeys();

			if (myRset != null && myRset.next()) {
				Long key = myRset.getLong(1);
				coupon.setID(key);
			}
			System.out.println("coupon create successfuly");
		} catch (CouponException | activationException |SQLException e) {
			logger.debug("COUPON CREATE FAILED"+toString());
		} finally {
			CP.returnConnection(myConn);
		}
	}
	/**REMOVE COUPON
	 * @throws activationException 
	 * @throws Throwable */

	@Override
	public void removeCoupon(long ID) throws CouponException, SQLException, activationException {
		Coupon coupon = new Coupon();
		try {
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("DELETE FROM coupon WHERE ID=?");
			myPstat.setLong(1, coupon.getID());
			myPstat.execute();
			logger.debug("coupon remove done");
		} catch (activationException | SQLException e) {
			logger.debug
			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
	}
	/**
	 * UPDATE COUPON
	 * @throws activationException 
	 */

	@Override
	public void updateCoupon(Coupon coupon) throws CouponException, SQLException, activationException {
		try {
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("UPDATE coupon SET IMAGE=?,PRICE=?,MESSAGE=?,TYPE=?,AMOUNT=?,END_DATE=?,END_TIME=?,START_TIME=?,START_DATE=?,TITLE=? WHERE ID=?");
			myPstat.setLong(1, coupon.getID());
			myPstat.setString(2,coupon.getTitle());
			myPstat.setDate(3,java.sql.Date.valueOf( coupon.getStartDate()));
			myPstat.setTime(4,java.sql.Time.valueOf( coupon.getStartTime()));
			myPstat.setDate(5, java.sql.Date.valueOf(coupon.getEndDate()));
			myPstat.setTime(6,java.sql.Time.valueOf( coupon.getEndTime()));
			myPstat.setInt(7, coupon.getAmount());
			myPstat.setString(8, coupon.getType().name());
			myPstat.setString(9, coupon.getMessage());
			myPstat.setDouble(10, coupon.getPrice());
			myPstat.setString(11, coupon.getImage());
			myPstat.executeUpdate();
			logger.debug("update coupon done ");
		}catch ( activationException | SQLException e) {
			logger.debug			("CHECK UPDATE AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
	}
	/**GET COUPON METHOD
	 * @throws activationException 
	 * @throws Throwable 
	 * @throws CouponProjectException 
	 * */
	@Override
	public Coupon getCoupon(long ID) throws CouponException, activationException, SQLException {
		Coupon coupon = new Coupon();
		try {
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("select * from coupon where ID=?");
			myPstat.setLong(1,ID);
			myRset= myPstat.executeQuery();   			
			if(!myRset.next())
				return null;
			coupon = getFromResultSet(myRset);
		}catch (activationException | SQLException e) {
			logger.debug("CHECK GET COUPON BY ID AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return coupon;
	}
	/**GET ALL COUPONS METHOD
	 * @throws CouponException 
	 * @throws activationException 
	 * @throws Throwable 
	 * */
	@Override
	public ArrayList<Coupon> getAllCoupon() throws CouponException, SQLException, activationException {
		ArrayList<Coupon> allCoupon=new ArrayList<Coupon>();			
		try {
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM coupon");
			myRset = myPstat.executeQuery();
			while(myRset.next()){
				allCoupon.add(new Coupon(

						myRset.getString("TITLE"),
						myRset.getDate("START_DATE").toLocalDate(),
						myRset.getTime("START_TIME").toLocalTime(),
						myRset.getDate("END_DATE").toLocalDate(),
						myRset.getTime("END_TIME").toLocalTime(),
						myRset.getInt("AMOUNT"),
						CouponType.valueOf(myRset.getString("type")),
						myRset.getString("message"),
						myRset.getDouble("price"),
						myRset.getString("IMAGE")));
			}
		} catch ( CouponProjectException |SQLException e) {
			logger.debug
			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return (ArrayList<Coupon>) allCoupon;
	}
	/**
	 * GET COUPON BY TYPE METHOD
	 */
	@Override
	public ArrayList<Coupon> getCopounByType(CouponType couponType) throws SQLException, CouponProjectException{
		try {
			return selectCoupons("coupon","TYPE","='"+couponType.toString()+"'");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 
	 * @param table
	 * @param where
	 * @param condition
	 * @return SELECT COUPONS FOR MORE SKILLS
	 * @throws CouponProjectException
	 * @throws SQLException
	 */
	public ArrayList<Coupon> selectCoupons(String table,String where,String condition)  throws CouponProjectException, SQLException  {
		ArrayList<Coupon> allCoupon=new ArrayList<>();
		try {	
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM "+table+" WHERE "+where+condition);
			myRset = myPstat.executeQuery();
			while(myRset.next()){
				allCoupon.add(new Coupon (

						myRset.getString("TITLE"),
						myRset.getDate("START_DATE").toLocalDate(),
						myRset.getTime("START_TIME").toLocalTime(),
						myRset.getDate("END_DATE").toLocalDate(),
						myRset.getTime("END_TIME").toLocalTime(),
						myRset.getInt("AMOUNT"),
						CouponType.valueOf(myRset.getString("type")),
						myRset.getString("message"),
						myRset.getDouble("price"),
						myRset.getString("IMAGE")));
			}
		} catch (CouponException | SQLException e) {
			logger.debug
			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return (ArrayList<Coupon>) allCoupon;

	}
	/**
	 * CHECK IF THE COUPON ALLREDY EXIST
	 */
	@Override
	public boolean isCoupon(long ID) throws CouponException, activationException{
		boolean isCoupon = false;

		try{
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement
					("SELECT * FROM Coupon WHERE ID='"+ID+"'");
			myRset = myPstat.executeQuery();
			if (myRset.next()) {
				isCoupon = true;
				return true;
			}
		} catch (SQLException | activationException e) {
			logger.debug(e.toString()+ "is coupon faild");
			return true;	
		} finally {
			CP.returnConnection(myConn);
		}
		return isCoupon;
	}

	/**
	 * GET ALL COUPONS BY CUSTOMER
	 * @param customer
	 * @return
	 * @throws CouponProjectException
	 * @throws SQLException
	 */
	public ArrayList<Coupon> getCustomerCoupons(Customer customer) throws CouponProjectException, SQLException   {
		return selectCoupons
				("customer_coupon JOIN Coupon ON COUPONS_ID=ID","CUST_ID ","="+customer.getID());
	}

	/**
	 * GET ALL PURCHASE COUPON BY MAX PRICE FOR THE CUSTOMER HOES BUY THE COUPON 
	 */
	@Override
	public ArrayList<Coupon> getCouponByMaxPrice(Company company, double price) throws CouponProjectException, SQLException   {
		return selectCoupons("company_coupon JOIN Coupon ON COUPON_ID=ID","COMP_ID ","="+company.getID()+" AND PRICE<="+price);
	}
	/**
	 * GET COUPONS BY LATE DATE 
	 */
	@Override
	public ArrayList<Coupon> getCouponByLateDate(Company company, LocalDate endDate) throws CouponProjectException, SQLException   {
		return selectCoupons("company_coupon JOIN Coupon ON COUPON_ID=ID","COMP_ID","="+company.getID()+" AND END_DATE<='"+endDate+"'");
	}

	@Override
	public void removeCoupon(Coupon coupon) {
		// TODO Auto-generated method stub

	}

	@SuppressWarnings("unused")
	@Override
	public void getCouponByTitle(String title) throws CouponException, activationException {
		Coupon coupon = new Coupon();
		try {
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("select * from coupon where TITLE=?");
			myPstat.setString(2,title);
			myRset= myPstat.executeQuery();   			
			if(!myRset.next())
				return;
			coupon = getFromResultSet(myRset);
		}catch (activationException | SQLException e) {
			logger.debug("CHECK GET COUPON BY TITLE AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return;
	}		
}
