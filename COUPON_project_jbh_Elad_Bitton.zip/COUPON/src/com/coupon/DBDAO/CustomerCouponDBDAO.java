package com.coupon.DBDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.basic.Customer;
import com.coupon.connectionPool.ConnectionPool;

import com.coupon.dao.CustomerCouponDao;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.activationException;

public class CustomerCouponDBDAO  implements CustomerCouponDao{
	/**
	 * Creating tools from imported java.sql classes to work with database:*
	 */
	Connection myConn;
	PreparedStatement myPstat;
	Statement myStat;
	ResultSet myRset;
	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CustomerCouponDBDAO.class);
	/**
	 * getting an instance of a connection from the ConnectionPool:
	 */
	ConnectionPool CP;
	public CustomerCouponDBDAO() throws CustomerException, activationException{
		CP =  ConnectionPool.getInstance();
	}
	/**
	 * GET COUPONS BY TYPE 
	 */
	public HashSet<Coupon> getCouponsByType(CustomerDBDAO customer) throws SQLException, activationException, CustomerException {
		Set<Coupon> coupons = new HashSet<>();
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myRset = myStat.executeQuery
					("SELECT TYPE FROM coupon "
							+ "WHERE CUST_ID ="
							+ customer.getCustomerByID(0));

			if(myRset == null)
				logger.debug				("NO MORE COUPONS!!!");
			while (myRset.next()){
				coupons.add(new CouponDBDAO().getCoupon(myRset.getInt(1)));
			}
			return (HashSet<Coupon>) coupons;

		} catch (CouponException e) {
			throw new CustomerException
			("CONNECTION FAILD...CHECK AGAIN!!!");
		} finally {
			CP.returnConnection(myConn);
		}
	}

	/**
	 *Checking a Customers Purchased coupons in order to understand 
	 *if that coupon was already purchased by that customer: 
	 *@param customer
	 *@param coupon
	 *@return true
	 * @throws activationException 
	 * @throws CustomerException 
	 */
	@Override
	public boolean IsBought(CustomerDBDAO customer, CouponDBDAO coupon) throws SQLException, activationException, CustomerException {
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myRset = myStat.executeQuery("SELECT COUPON_ID FROM customer_coupon"
					+ " WHERE CUST_ID = "+customer.getCustomerByID(0)+"");
			while(myRset.next()){
				if(coupon.getCoupon(0) == myRset.getObject(0))
					return true;
			}
		} catch (CouponException e) {
			logger.debug	("CONNECTION FAILED , PLEASE CHECK AGAIN");
		}  finally {
			CP.returnConnection(myConn);
		}
		return false;
	}
	/**
	 *Adding Customer's ID and the Customers's Coupon's ID to the Join table in the database: 
	 *@param customer
	 *@param coupon
	 *@throws CouponException
	 */
	public void addCustomerCoupon(long customer, long coupon) throws CustomerException , activationException, CouponException, SQLException {
		try {
			CouponDBDAO couponDBDAO = new CouponDBDAO();
			if (!couponDBDAO.isCoupon(coupon))
				logger.debug("coupon id not exist ");
			CustomerDBDAO customerDBDAO = new CustomerDBDAO();
			if (!customerDBDAO.isCustomer(customer))
				logger.debug	("customer ID not exist...check again");
			myConn = CP.getConnection();
			myPstat = myConn.prepareStatement("INSERT INTO customer_coupon (CUST_ID, COUPON_ID) VALUES(?,?)");
			myPstat.executeUpdate();
		} catch (CouponException e) {
			logger.debug	("there is a problem in the connection to the database.");
		}  finally {
			CP.returnConnection(myConn);
		}
	}
	/**
	 *Removing a Customer from the Joined Customer-Coupon table in the database by the Customer's ID: 
	 *@param customer
	 *@throws CouponException
	 */
	public void removeCustomerCoupon(long ID) throws CustomerException , activationException, SQLException {
		Updator("delete from customer_coupon where COUP_ID=?", ID);
	}
	/**
	 * remove all customer coupons
	 * @throws activationException 
	 * @throws CustomerException 
	 * @throws Throwable 
	 */
	public void removeCustomerCoupon(CouponDBDAO coupon) throws SQLException, activationException, CustomerException  {
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myStat.execute
			("DELETE FROM customer_coupon WHERE COUPON_ID = "+coupon.getCoupon(0)+"");

		} catch (CouponException e) {
			logger.debug	("there is a problem in the connection to the database.");
		} finally {
			CP.returnConnection(myConn);	
		}
	}
	/**
	 * GET ALL COUPONS BY CUSTOMERS
	 * @throws activationException 
	 * @throws CustomerException 
	 * @throws Throwable 
	 * 
	 */
	@Override
	public HashSet<Coupon> getCoupons(CustomerDBDAO customer) throws  SQLException, activationException, CustomerException  {
		Set<Coupon> coupons = new HashSet<>();
		try {
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myRset = myStat.executeQuery
					("SELECT COUPON_ID FROM customer_coupon "
							+ "WHERE CUST_ID ="
							+ customer.getCustomerByID(0));

			if(myRset == null)
				logger.debug					("NO MORE COUPONS!!!");
			while (myRset.next()){
				coupons.add(new CouponDBDAO().getCoupon(myRset.getInt(1)));
			}
			return (HashSet<Coupon>) coupons;

		} catch (  CouponException e) {
			logger.debug				("CONNECTION FAILD...CHECK AGAIN!!!");
		} finally {
			CP.returnConnection(myConn);
		}
		return null;
	}
	/**
	 * UPDATOR - PRIVATE UPDATE METHOD 
	 * @param DB
	 * @param ID
	 * @throws SQLException
	 * @throws activationException
	 */
	private void Updator(String DB, long ID) throws SQLException, activationException {

		myConn= CP.getConnection();
		try {
			myPstat = myConn.prepareStatement(DB);
			myPstat.setLong(1, ID);
			myPstat.executeUpdate();
		} catch (SQLException e) {
			logger.debug	(e.toString());
		} finally {
			CP.returnConnection(myConn);
		}

	}
	public static void DeleteAllCouponsbyID(Long longID) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * GET ALL PURCHASE COUPON BY TYPE FOR THE CUSTOMER HOES BUY THE COUPON 
	 */
	public ArrayList<Coupon> getAllPurchasedCustomerCouponsByType(Customer customer ,CouponType type) throws CouponProjectException, SQLException   {
		return selectCoupons("Coupon JOIN customer_coupon ON ID=COUPON_ID","CUST_ID ","="+customer.getID()+" AND TYPE='"+type.toString()+"'");
	}
	/**
	 * GET ALL PURCHASE COUPON BY PRICE FOR THE CUSTOMER HOES BUY THE COUPON 
	 */
	@Override
	public ArrayList<Coupon> getAllPurchasedCustomerCouponsByPrice(Customer customer,Coupon price) throws CouponProjectException, SQLException   {
		return selectCoupons("Coupon JOIN customer_coupon ON ID=COUPONS_ID","CUST_ID ","="+customer.getID()+" AND PRICE<="+price);

	}
	public ArrayList<Coupon> selectCoupons(String table,String where,String condition)  throws CouponProjectException, SQLException  {
		ArrayList<Coupon> allCoupon=new ArrayList<>();
		try {	
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM "+table+" WHERE "+where+condition);
			myRset = myPstat.executeQuery();
			while(myRset.next()){
				allCoupon.add(new Coupon (

						myRset.getString("TITLE"),
						myRset.getDate("START_DATE").toLocalDate(),
						myRset.getTime("START_TIME").toLocalTime(),
						myRset.getDate("END_DATE").toLocalDate(),
						myRset.getTime("END_TIME").toLocalTime(),
						myRset.getInt("AMOUNT"),
						CouponType.valueOf(myRset.getString("type")),
						myRset.getString("message"),
						myRset.getDouble("price"),
						myRset.getString("IMAGE")));
			}
		} catch (CouponException | SQLException e) {
			logger.debug
			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return (ArrayList<Coupon>) allCoupon;

	}

}
