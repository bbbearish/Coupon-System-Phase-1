package com.coupon.DBDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.connectionPool.ConnectionPool;

import com.coupon.dao.CompanyCoponDao;
import com.coupon.dao.CompanyDAO;
import com.coupon.dao.CouponDao;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;

public class CompanyCouponDBDAO   implements CompanyCoponDao  {
	/**
	 *TOOLS FOR TO WORK WITH THE DB FROM JAVA
	 */
	Connection myConn;
	PreparedStatement myPstat;
	ResultSet myRset;
	Statement myStat;
	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CompanyCouponDBDAO.class);
	/**
	 * GETTING INSTANCE CONNECTION FROM CONNECTIONPOOL CLASS
	 */
	ConnectionPool CP;
	public  CompanyCouponDBDAO() throws CompanyException, activationException {
		CP = ConnectionPool.getInstance();	
	}	
	/**
	 * private get from RS coupon details by company
	 * @param myRset
	 * @return
	 * @throws SQLException
	 * @throws CouponException
	 */
	private Coupon getFromResultSet(ResultSet myRset) throws SQLException, CouponException {
		Coupon coupon = new Coupon();
		coupon.setID(myRset.getLong("ID"));
		coupon.setTitle(myRset.getString("TITLE"));
		coupon.setAmount(myRset.getInt("AMOUNT"));
		coupon.setStartDate(myRset.getDate("START_DATE").toLocalDate());
		coupon.setStartTime(myRset.getTime("START_TIME").toLocalTime());
		coupon.setEndDate(myRset.getDate("END_DATE").toLocalDate());
		coupon.setEndTime(myRset.getTime("END_TIME").toLocalTime());
		coupon.setImage(myRset.getString("IMAGE"));
		coupon.setMessage(myRset.getString("MESSAGE"));
		coupon.setPrice(myRset.getDouble("PRICE"));
		String couponType = myRset.getString("TYPE");
		coupon.setCouponType(CouponType.valueOf(couponType));
		return coupon;
	}
	/**
	 * private update method 
	 * @param DBSstate
	 * @param values
	 * @throws SQLException
	 * @throws CompanyException
	 * @throws activationException
	 */
	private void updateMethods(String DBSstate, long values) throws SQLException, CompanyException, activationException {
		myConn = CP.getConnection();
		try {
			myPstat = myConn.prepareStatement(DBSstate);
			myPstat.setLong(1, values);
			myPstat.executeUpdate();

		} catch (SQLException e) {
			logger.debug("check the update method!!!" + e.toString());
		} finally {
			CP.returnConnection(myConn);
		}
	}
	/**
	 * ADD ALL COUPONS THAT BELONGE TO SOME COMPANY
	 * @throws activationException 
	 * @throws CouponException 
	 */
	@Override
	public void addCompanyCoupon(long companyID, long couponID) throws CompanyException, activationException, CouponException {
		try {
			myConn = CP.getConnection();
			CouponDao couponDBDAO = new CouponDBDAO();
			if (!couponDBDAO.isCoupon(couponID))
				logger.debug("the coupon not exist... please check again");

			CompanyDAO companyDBDAO = new CompanyDBDAO();
			if (!companyDBDAO.isCompany(companyID))
				logger.debug(
						"somthing wong , check your id again please");
			myPstat = myConn.prepareStatement("INSERT INTO company_coupon VALUES(" + companyID + ","+ couponID + ")"
					,Statement.RETURN_GENERATED_KEYS);

			myPstat.executeUpdate(); 

		}catch(SQLException e){
			logger.debug ("CHECK ADD COMPANY COUPON METHOD");
		} finally {
			CP.returnConnection(myConn);
		}	
	}


	/**
	 * REMOVE ALL COUPON TO THE COMPANY THAT WE REMOVE
	 * @throws activationException 
	 * @throws CouponException 
	 */
	@Override
	public void removeCompanyCoupon(long compID) throws CompanyException, activationException, CouponException {
		try {
			updateMethods("delete from company_coupon where compID=?", compID);
		} catch (SQLException e) {
			logger.debug("check your remove company coupon method");
		}
	}
	/**
	 * GET ALL COUPONS BY COMPANYS
	 * @throws Throwable 
	 * @throws SQLException 
	 * @throws CompanyException 
	 * @throws activationException 
	 * @throws CouponException 
	 *  */
	@Override
	public Collection<Coupon> getCoupons(long companyID) throws  SQLException, CompanyException, activationException, CouponException {
		Collection<Coupon> coupons = new ArrayList<Coupon>();
		myConn = CP.getConnection();
		try {
			String sql = "SELECT * from coupon c JOIN company_coupon cc ON c.ID = cc.couponID WHERE cc.compID=?";
			PreparedStatement ps = myConn.prepareStatement(sql);
			ps.setLong(1, companyID);

			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				Coupon coupon = getFromResultSet(rs);
				coupons.add(coupon);
			}
		} catch (SQLException e) {
			logger.debug("check get company coupon method" + e.toString());
		} finally {
			CP.returnConnection(myConn);
		}
		return coupons;
	}
	@Override
	public  void DeleteAllCompanyCoupons(long companyID) throws CompanyException, activationException {
		Connection myconn = null;
		ConnectionPool connPool = null;
		try {
			connPool = ConnectionPool.getInstance();
			myconn = connPool.getConnection();

			Statement stmt = myconn.createStatement();
			String sql = "DELETE FROM CompanyCoupon WHERE Comp_ID=" + companyID;
			stmt.executeUpdate(sql);

		} catch (SQLException e) {
			logger.debug("Delete all company coupons failed" + e.toString());
		} finally {
			if (connPool != null && myconn != null)
				connPool.returnConnection(myconn);
		}

	}
	
	@Override
	public Collection<Long> GetAllCompanyCoupons(long companyID)throws CouponException, activationException {
		Connection con = null;
		ConnectionPool connPool = null;
		Collection<Long> Coupons = new ArrayList<Long>();
		try {
			connPool = ConnectionPool.getInstance();
			con = connPool.getConnection();

			Statement stmt = con.createStatement();
			String sql = "Select * FROM company_coupon WHERE Comp_ID="
					+ companyID;
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				Coupons.add(rs.getLong("Coupon_ID"));
			}

		} catch (SQLException e) {
			logger.debug("Get company coupons failed"+toString());
		} finally {
			if (connPool != null && con != null)
				connPool.returnConnection(con);
		}
		return Coupons;

	}
	/**
	 * GET ALL COUPONS BY COMPANY
	 */
	@Override
	public ArrayList<Coupon> getCompanyCoupons(Company company)throws CouponProjectException, SQLException {
		return selectCoupons
				("company_coupon JOIN Coupon ON COUPON_ID=ID","COMP_ID","="+
						company.getID());

	}
	public ArrayList<Coupon> selectCoupons(String table,String where,String condition)  throws CouponProjectException, SQLException  {
		ArrayList<Coupon> allCoupon=new ArrayList<>();
		try {	
			myConn=CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM "+table+" WHERE "+where+condition);
			myRset = myPstat.executeQuery();
			while(myRset.next()){
				allCoupon.add(new Coupon (

						myRset.getString("TITLE"),
						myRset.getDate("START_DATE").toLocalDate(),
						myRset.getTime("START_TIME").toLocalTime(),
						myRset.getDate("END_DATE").toLocalDate(),
						myRset.getTime("END_TIME").toLocalTime(),
						myRset.getInt("AMOUNT"),
						CouponType.valueOf(myRset.getString("type")),
						myRset.getString("message"),
						myRset.getDouble("price"),
						myRset.getString("IMAGE")));
			}
		} catch (CouponException | SQLException e) {
			logger.debug
			("CONNECTION FAILD...CHECK AGAIN!!!");			
		} finally {
			CP.returnConnection(myConn);
		}
		return (ArrayList<Coupon>) allCoupon;

	}


}

