package com.coupon.DBDAO;
import java.sql.*;
import java.util.*;

import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.connectionPool.ConnectionPool;

import com.coupon.dao.CompanyDAO;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;

public class CompanyDBDAO     implements CompanyDAO {
	/**
	//TOOLS FOR TO WORK WITH THE DB FROM JAVA
	 */
	Connection myConn;
	PreparedStatement myPstat;
	ResultSet myRset;
	Statement myStat;
	/**
	 * GETTING INSTANCE CONNECTION FROM CONNECTIONPOOL CLASS
	 */
	ConnectionPool CP;
	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(CompanyDBDAO.class);
	/**
	 * Constructor with connection pool
	 * @throws CompanyException
	 * @throws activationException
	 */
	public CompanyDBDAO() throws CompanyException, activationException {
		CP = ConnectionPool.getInstance();	
	}	
	/**
	 * GET FROM RESULT SET METHOD
	 * @param myRset
	 * @return
	 * @throws SQLException
	 * @throws CompanyException
	 */
	@SuppressWarnings("unused")
	private Company getFromResultSet(ResultSet myRset) throws SQLException, CompanyException {
		long ID = myRset.getLong("ID");
		String name = myRset.getString("COMPANY_NAME");
		String password = myRset.getString("PASSWORD");
		String email = myRset.getString("EMAIL");

		Company company = new Company();
		company.setID(ID);
		company.setCompName(name);
		company.setPassword(password);
		company.setEmail(email);

		return company;
	}	

	/**
	 * CREATE A NEW COMPANY
	 * @throws CompanyException 
	 * @throws activationException 
	 * */
	@Override
	public void createCompany(Company company) throws CompanyException, activationException {
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement
					("INSERT INTO company(COMPANY_NAME, PASSWORD, EMAIL) VALUES(?,?,?)", Statement.RETURN_GENERATED_KEYS);
			myPstat.setString(1, company.getCompName());
			myPstat.setString(2, company.getPassword());
			myPstat.setString(3, company.getEmail());
			myPstat.executeUpdate();
			myRset= myPstat.getGeneratedKeys();
			if(myRset!= null && myRset.next()) {
				Long key= myRset.getLong(1);
				company.setID(key);
			}
			logger.debug("WELCOME " + company.getCompName());
		}catch (SQLException  | CompanyException e){
			logger.debug("CREATE COMPANY FAIL...CHECK AGAIN"+toString());
		}finally {
			CP.returnConnection(myConn);
		}
	}

	/**
	 * REMOVE  COMPANY BY ID 
	 * @throws activationException 
	 * @throws CompanyException
	 * @throws CouponException 
	 * */
	@Override
	public void removeCompany(long ID) throws CompanyException, activationException, CouponException{
		myConn= CP.getConnection();
		CompanyCouponDBDAO companyCouponDBDAO = new CompanyCouponDBDAO();
		boolean booliTransaction = false;
		try {
			booliTransaction = myConn.getAutoCommit(); 
			if (booliTransaction)myConn.setAutoCommit(false);
			companyCouponDBDAO.removeCompanyCoupon(ID);
			String DB = "delete from company where ID=?";
			myPstat = myConn.prepareStatement(DB);
			myPstat.setLong(1, ID);

			int rowsLeftToCheck = myPstat.executeUpdate();
			if (rowsLeftToCheck == 0) {
				throw new SQLException("removeCompany id failed");
			}				

			if (booliTransaction)
				myConn.commit(); 
			logger.debug("company remove done!");
		} catch (SQLException | CompanyException e) {
			logger.debug("removeCompany failed : " + e.toString());		
		} finally {
			CP.returnConnection(myConn);
		}

	}

	@Override
	public void removeCompany(Company company) throws SQLException, CompanyException, activationException, CouponException {
		removeCompany(company.getID());
	}



	/**
	 * UPDATE COMPANY
	 * @throws activationException 
	 * @throws SQLException 
	 * @ throws CompanyException
	 * */
	@Override
	public void updateCompany(Company company) throws CompanyException, activationException, SQLException {
		myConn= CP.getConnection();
		boolean booliTransaction = false;
		try {
			myPstat = myConn.prepareStatement
					("UPDATE Company SET COMPANY_NAME = ? ,PASSWORD=?, EMAIL=? WHERE ID=?");

			myPstat.setString(1, company.getCompName());
			myPstat.setString(2, company.getPassword());
			myPstat.setString(3, company.getEmail());
			myPstat.executeUpdate();


			int rowsLeftToCheck = myPstat.executeUpdate();
			if (rowsLeftToCheck == 0) {
				throw new SQLException("updateCompany failed");
			}				

			if (booliTransaction)
				myConn.commit(); 
			logger.debug("update is done!");

			System.out.println("Company has been updated success " + company);
		} catch (SQLException e) {
			logger.debug ("updateCompany failed : " + e.toString());
		} finally {
			CP.returnConnection(myConn);

		}

	}

	/**
	 * GET COMPANY FROM THE DB BY ID 
	 * @throws CompanyException 
	 * @throws activationException 
	 * */
	@Override
	public Company getCompanyByID(long ID) throws CompanyException, activationException {
		Company company = null;
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM company WHERE ID="+ID);
			myRset=myPstat.executeQuery();
			if (myRset.next()){
				company= new Company(
						myRset.getString("COMPANY_NAME"),
						myRset.getString("PASSWORD"),
						myRset.getString("EMAIL")
						);
			}else{
				if(ID!=0){
					logger.debug("THERE IS NO CONPANY WITH ID : "+ID);
				}else{
					logger.debug ("THE COMPANY NOT FOUND...CHECK AGAIN!!!");
				}
			}
			return company ;
		}catch (SQLException | CouponProjectException e){
			logger.debug(e.toString() + "check again get company by ID ...");
		} finally {
			CP.returnConnection(myConn);
		}
		return company;
	}
	/**
	 * GET THE WHOLE COMPANYS FROM THE DB BY NAME 
	 * @throws activationException 
	 * */
	@Override
	public Company getCompanyByName(String name) throws CompanyException, activationException {
		Company company = null;
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM Company WHERE COMPANY_NAME='"+name+"'");
			myRset=myPstat.executeQuery(); 
			if (myRset.next()){
				company= new Company(
						myRset.getString("COMPANY_NAME"),
						myRset.getString("PASSWORD"),
						myRset.getString("EMAIL")
						);
			}else{
				logger.debug("THE COMPANY"+name+"DOSEN'T EXIST");
			}
		}catch (SQLException | CouponProjectException e){
			logger.debug("faild to get the company"+e.toString());
		} finally {
			CP.returnConnection(myConn);
		}
		return company;
	}

	/**
	 * GET HASH SET OF COMPANYS
	 */
	@Override
	public Set<Company> getAllCompanys ()throws CompanyException, activationException{
		Set<Company> companies= new HashSet<>();
		try{	
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM company");
			myRset= myPstat.executeQuery();
			if (myRset==null)
				logger.debug("NO COMPANY FOUND...");
			while (myRset.next()){ 
				Company company1 = new Company
						(myRset.getString("COMPANY_NAME"), myRset.getString("PASSWORD"), myRset.getString("EMAIL"));
				companies.add(company1);
			}
		}catch (SQLException  e){
			logger.debug("CONNECTION TO THE DB FAILD... ");
		} finally {
			CP.returnConnection(myConn);
		}
		return companies;
	}

	/**
	 * LOGIN FUNCTION
	 * @throws activationException 
	 * */
	@Override
	public boolean login(String email, String password) throws CompanyException, activationException{
		try{
			myConn = CP.getConnection();
			myStat = myConn.createStatement();
			myRset = myStat.executeQuery
					("SELECT PASSWORD FROM Company WHERE EMAIL='"+email+"'");	
			if(myRset.next())
				if (password.equals(myRset.getString(1))){
					logger.debug("WELLCOME "+ email);
					return true;
				}else	{
					logger.debug("Incorect Password");
				}else
					logger.debug
					("there is no such company MAIL in database");

		}catch(SQLException e){
			throw new CompanyException("CONNECTION TO THE DB FAILD... ");
		} finally {
			CP.returnConnection(myConn);
		}
		return false;
	}
	/**
	 * CHECK FOR DUPLICATES WHEN YOU CREATE COMPANY
	 * @throws activationException 
	 * */
	@Override
	public boolean isCompany(long compID) throws CompanyException, activationException {
		boolean isCompany = false;
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement			
					("Select * FROM Company WHERE ID=" + compID);
			myRset= myPstat.executeQuery();
			if(myRset.next()){
				isCompany = true;
				System.out.println("THE ID NUMBER "+compID + " IS "+isCompany);
			}
		}catch (SQLException e){
			logger.debug("CONNECTION TO THE DB FAILD... ");
		} finally {
			CP.returnConnection(myConn);
		}
		return isCompany;
	}

	/**
	 * CHECK FOR DUPLICATES WHEN YOU CREATE COMPANY
	 * @throws activationException 
	 * 
	 * */
	@Override
	public boolean isCompanyEmail(String Email) throws CompanyException, activationException {
		boolean isCompanyEmail = false;
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement			
					("Select * FROM Company WHERE EMAIL=" + Email);
			myRset= myPstat.executeQuery();
			if(myRset.next()){
				isCompanyEmail = true;
				System.out.println("THE ID NUMBER "+Email + " IS "+isCompanyEmail);
			}
		}catch (SQLException e){
			logger.debug("CHECK IS COMPANY EMAIL METHOD!!! "+toString());
		} finally {
			CP.returnConnection(myConn);
		}
		return isCompanyEmail;
	}
	/**
	 * GET THE WHOLE COMPANYS FROM THE DB BY NAME 
	 * @throws activationException 
	 * */
	@Override
	public Company getCompanyByEmail(String Email) throws CompanyException, activationException {

		Company company = new Company();
		try{
			myConn= CP.getConnection();
			myPstat = myConn.prepareStatement("SELECT * FROM Company WHERE EMAIL='"+Email+"'");
			myRset=myPstat.executeQuery(); 
			if (myRset.next()){
				company= new Company(
						myRset.getString("COMPANY_NAME"),
						myRset.getString("PASSWORD"),
						myRset.getString("EMAIL")
						);
			}else{
				logger.debug("THE COMPANY"+Email+"DOSEN'T EXIST");
			}
		}catch (SQLException | CouponProjectException e){
			logger.debug("faild to get the company"+e.toString());
		} finally {
			CP.returnConnection(myConn);
		}
		return company;
	}


}
