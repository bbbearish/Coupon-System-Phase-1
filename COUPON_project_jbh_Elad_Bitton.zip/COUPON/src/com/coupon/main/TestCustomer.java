package com.coupon.main;

import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.basic.Customer;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.activationException;
import com.coupon.facade.CustomerFacade;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.*;


public class TestCustomer {

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(TestCustomer.class);
	public TestCustomer() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * test 1 
	 */
	public void test() {
		printCustomer();
		purchaseCouponByTitle("googlxkke watch");
		purchaseCouponByTitle("apple watch");
		purchaseCouponByTitle("bearish wath ");
		purchaseCouponByTitle("solo babo masho");
		purchaseCouponByTitle("sink");
		purchaseCouponByTitle("maos");
		purchaseCouponByTitle("phone");
		purchaseCouponByTitle("lady gaga show"); 

		printCustomer();
		printCouponsByType(CouponType.FOOD);
		printCouponsByType(CouponType.CAMPING);
		printCouponsByType(CouponType.GADJETS);
		printCouponsByType(CouponType.ELECTRICITY); 
		printCouponsByPrice(50);
		printCouponsByPrice(2000);
	}
	/**
	 *  customer that login to the faced
	 */
	private void printCustomer() {
		CustomerFacade customerFacade = new CustomerFacade();
		try {
			Customer customer = customerFacade.getCustomer(); 
			System.out.println(customer + " num coupons = " + customer.getCoupons().size());

			printCoupons(customer.getCoupons(), "\t");
		} catch (Exception e) {
			logger.error("printCustomer failed : " + e.toString());
		}
	}
	/**
	 * purchase Coupon By Title
	 * @param couponTitle
	 */
	private void purchaseCouponByTitle(String couponTitle) {
		CustomerFacade customerFacade = new CustomerFacade();

		System.out.println(couponTitle);
		try {
			customerFacade.purchaseCoupon(couponTitle);
		} catch (Exception e) {
			logger.error("purchaseCoupon  failed : " + e.toString());
		}
	}
	/**
	 * printCoupons - prints a list of Coupons.
	 * @param coupons the list of Coupons
	 * @param prefix a prefix. for example use \t or blanks for indentation.
	 */
	private void printCoupons(Collection<Coupon> coupons, String prefix) {
		for (Coupon coupon : coupons) {
			System.out.println(prefix + coupon);
		}
	}
	/**
	 * print coupons with empty prefix
	 * @param coupons
	 */
	private void printCoupons(Collection<Coupon> coupons) {
		printCoupons(coupons, ""); 
	}
	/**
	 * get coupon by type
	 * @param type
	 * @return
	 * @throws Exception
	 */
	private Collection<Coupon> getCouponByType(CouponType type) throws Exception {
		CustomerFacade customerFacade = new CustomerFacade();

		Collection<Coupon> coupons = new ArrayList<Coupon>();
		Customer customer = customerFacade.getCustomer();
		for (Coupon coupon : customer.getCoupons()) {
			if (coupon.getType() == type)
				coupons.add(coupon);
		}
		return coupons;
	}
	/**
	 * GET COUPONS BY PRICE
	 * @param price
	 * @return
	 * @throws activationException 
	 * @throws Exception
	 */
	private Collection<Coupon> getCouponsByPrice(long price) throws CustomerException, activationException {
		CustomerFacade customerFacade = new CustomerFacade();
		Collection<Coupon> coupons = new ArrayList<Coupon>();
		Customer customer = customerFacade.getCustomer(); 
		for (Coupon coupon : customer.getCoupons()) {
			if (coupon.getPrice() <= price)
				coupons.add(coupon);
		}

		return coupons;
	}

	/**
	 * GET COUPONS BY PRICE 
	 * @param price
	 */
	private void printCouponsByPrice(long price) {
		try {
			Collection<Coupon> coupon = getCouponsByPrice(price);
			System.out.println("coupons cheaper then " + price);
			printCoupons(coupon);
		} catch (Exception e) {
			logger.error("printCouponsByPrice  failed : " + e.toString());

		}
	}
	/**
	 * PRINT COUPONS BY TYPE
	 * @param type
	 */
	private void printCouponsByType(CouponType type) {
		try {
			Collection<Coupon> coupon = getCouponByType(type);
			System.out.println("coupons of type " + type);
			printCoupons(coupon);
		} catch (Exception e) {
			logger.error("printCouponsByType  failed : " + e.toString());

		}

	}



}
