package com.coupon.main;

import java.sql.SQLException;
import java.util.Collection;

import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.basic.Customer;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.LoginException;
import com.coupon.exceptions.CouponProjectException.activationException;
import com.coupon.facade.AdminFacade;

public class TestAdmin {

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(TestAdmin.class);


	public TestAdmin() {
	}

	public void testCouponSystem() throws CompanyException, CustomerException, activationException, CouponException, SQLException, LoginException {
		/**
		 * CREATE COMPANY
		 */
		System.out.println("creat companies");
		createComapny(new Company("BISH", "5xk","xzkjssp@kfksds.com"));
		createComapny(new Company("MEI", "52dzls42", "klsdkl@dzjsds.com"));
		createComapny(new Company("MdzBI", "4zx5", "kdzxkkldk@lfsasd.com"));

		printAllCompanies();
		/**
		 * UPDATE COMPANY
		 */
		System.out.println("updating companies");
		updateCompany(6);
		updateCompany(3);
		updateCompany(9);

		printAllCompanies();
		/**
		 * REMOVE COMPANY
		 */
		System.out.println("removing companies");
		removeCompany(6);
		removeCompany(8);

		printAllCompanies();

		/**
		 * CREATE CUSTOMER
		 */
		System.out.println("creating customers");
		createCustomer(new Customer("samxll kabai", "5556", "pxkjkjxonti@paxkkndi.com"));
		createCustomer(new Customer("samixxkk kssbai", "55d5xzk6", "poxkknti@pandfd.com"));
		createCustomer(new Customer("samsdxkjkx abai", "5556", "poxkjlnti@pdxklsdsdi.com"));
		createCustomer(new Customer("sdsmixkjx kabai", "5556", "ponxlklkxti@paxkjkjxnsdi.com"));
		createCustomer(new Customer("samixlklx kasddfi", "5556", "poxlklxsd@plklxklandi.com"));

		printAllCustomers();
		/**
		 * UPDATE CUSTOMER 
		 */
		System.out.println("updating customers");
		updateCustomer("bdds juns");
		updateCustomer("bass juns");

		printAllCustomers();
		/**
		 * REMOVE CUSTOMER
		 */
		System.out.println("removing customers");
		removeCustomer(2);
		removeCustomer(3);

		printAllCustomers();
	}
	/**
	 * PRINT ALL COMPANIES METHOD
	 */
	public void printAllCompanies() {
		Collection<Company> companies;
		try {
			AdminFacade adminFacade = new AdminFacade();
			companies = adminFacade.getAllCompanys();
			for (Company company : companies)
				System.out.println(company);
		} catch (Exception e) {
			logger.debug("check print all companies");
		}
	}
	/**
	 * CREATE COMPANY 
	 * @param name
	 * @throws LoginException 
	 * @throws CompanyException
	 * @throws activationException
	 * @throws SQLException
	 */
	public void createComapny(Company company) throws LoginException  {		
		try {
			AdminFacade adminFacade = new AdminFacade();
			adminFacade.createCompany(company);
		} catch (CompanyException | activationException e) {
			logger.debug(e.toString()+"create company");
		}
	}
	/**
	 * UPDATE COMPANY
	 * @param companyName
	 * @throws CompanyException
	 * @throws activationException
	 * @throws CouponException
	 * @throws SQLException
	 */
	public void updateCompany(long companyID) throws CompanyException, activationException, CouponException, SQLException {
		AdminFacade adminFacade = new AdminFacade();
		Company company = adminFacade.getCompanyByID(companyID);
		if (null == company) {
			return;
		}
		company.setEmail(company.getCompName() + "soxjxjlobolo@jbh.com");
		String password = company.getCompName().substring(0, 2) + "9999";
		company.setPassword(password);
		adminFacade.updateCompany(company);
	}
	/**
	 * REMOVE COMPANY
	 * @param ID
	 * @throws CompanyException
	 * @throws activationException
	 */
	public void removeCompany(long ID) throws CompanyException, activationException {
		AdminFacade adminFacade = new AdminFacade();

		System.out.println("removing company : " + ID);
		Company c = adminFacade.getCompanyByID(ID);
		if (null == c) {
			return;
		}
		try {
			adminFacade.RemoveCompanyByID(c.getID());
		} catch (Exception e) {
			logger.debug("remove company faild");
		}
	}
	
	/**
	 * PRINT ALL CUSTOMERS
	 * @throws CustomerException
	 * @throws activationException
	 */
	public void printAllCustomers() throws CustomerException, activationException {
		AdminFacade adminFacade = new AdminFacade();
		Collection<Customer> coustomers = adminFacade.getAllCustomers();
		for (Customer customer : coustomers)
			System.out.println(customer);
	}
	/**
	 * CREATE A NEW CUSTOMER 
	 * @param name
	 * @throws CustomerException
	 * @throws activationException
	 */
	public void createCustomer(Customer customer) throws CustomerException, activationException {
		AdminFacade adminFacade = new AdminFacade();
		try {
			adminFacade.createCustomer(customer);
		} catch (CustomerException e) {
			logger.debug("create customer main prob");
		}
	}
	/**
	 * UPDATE A CUSTOMER 
	 * @param customerName
	 * @throws CustomerException
	 * @throws activationException
	 */
	public void updateCustomer(String customerName) throws CustomerException, activationException {
		AdminFacade adminFacade = new AdminFacade();

		Customer c = adminFacade.getCustomerByName(customerName);
		if (null == c) {
			return;
		}
		String password = c.getCustName().substring(0, 2) + "9999";
		c.setPassword(password);
		try {
			adminFacade.updateCustomer(c);
		} catch (Exception e) {
			logger.debug("update customer failed");

		}
	}
	/**
	 * REMOVE A CUSTOMER 
	 * @param ID
	 * @throws CustomerException
	 * @throws activationException
	 */
	public void removeCustomer(long ID) throws CustomerException, activationException {
		AdminFacade adminFacade = new AdminFacade();

		System.out.println("removing customer : " + ID);
		Customer c = adminFacade.getCustomerById(ID);
		if (null == c) {
			return;
		}
		try {
			adminFacade.removeCustomer(c.getID());
		} catch (CustomerException e) {
			logger.debug("remove customer prob");
		}
	}

}

