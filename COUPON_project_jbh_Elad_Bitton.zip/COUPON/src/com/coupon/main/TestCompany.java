package com.coupon.main;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collection;
import org.apache.log4j.Logger;

import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;
import com.coupon.facade.CompanyFacade;

public class TestCompany {

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(TestCompany.class);

	public TestCompany( ) {
	}

	public void test() throws activationException, CompanyException, SQLException, CouponProjectException {
		/**
		 * create coupon
		 */
		printCompany();
		System.out.println("creating coupons");
		createCoupon(new Coupon("soxkkxlo", LocalDate.of(2016, 05, 06), LocalTime.of(22, 55), LocalDate.of(2016, 8, 05), LocalTime.of(23, 55), 30, CouponType.CAMPING, "skfhkdf", 33.50, "jdkjk"));
		createCoupon(new Coupon("soxzkjdslo", LocalDate.of(2016, 05, 06), LocalTime.of(22, 55), LocalDate.of(2016, 8, 05), LocalTime.of(23, 55), 30, CouponType.CAMPING, "skfhkdf", 33.50, "jdkjk"));
		createCoupon(new Coupon("soaxjzkjzalo", LocalDate.of(2016, 05, 06), LocalTime.of(22, 55), LocalDate.of(2016, 8, 05), LocalTime.of(23, 55), 30, CouponType.CAMPING, "skfhkdf", 33.50, "jdkjk"));
		createCoupon(new Coupon("sodsskskfklo", LocalDate.of(2016, 05, 06), LocalTime.of(22, 55), LocalDate.of(2016, 8, 05), LocalTime.of(23, 55), 30, CouponType.CAMPING, "skfhkdf", 33.50, "jdkjk"));
		createCoupon(new Coupon("soxkjkzzdkjsdklo", LocalDate.of(2016, 05, 06), LocalTime.of(22, 55), LocalDate.of(2016, 8, 05), LocalTime.of(23, 55), 30, CouponType.CAMPING, "skfhkdf", 33.50, "jdkjk"));


		/**
		 * remove coupon
		 */
		printCompany();
		System.out.println("removing coupons");
		removeCoupon(1);
		removeCoupon(5); 
		/**
		 * update coupon
		 */
		printCompany();
		System.out.println("updating coupons");
		updateCoupon(2);
		printCompany();
		printCouponsByType(CouponType.FOOD);
		printCouponsByType(CouponType.ELECTRICITY); // supposed to be empty
		printCouponsByType(CouponType.GADJETS);
		printCouponsByPrice(30);
		printCouponByDate(LocalDate.of(2016, 01, 31));
	}


	/**
	 * PRINT COUPONS METHOD
	 * @param coupons
	 * @param prefix
	 */
	private void printCoupons(Collection<Coupon> coupons, String prefix) {
		for (Coupon coupon : coupons) {
			System.out.println(coupon +prefix);
		}
	}
	/**
	 * PRINT COUPONS WITH EMPTY PRIFIX METHOD
	 * @param coupons
	 */
	private void printCoupons(Collection<Coupon> coupons) {
		printCoupons(coupons, ""); 
	}
	/**
	 * PRINT COUPONS BY DATE 
	 * @param date
	 * @throws CouponException
	 */
	private void printCouponByDate(LocalDate date) throws CouponException {
		try {
			CompanyFacade companyFacade = new CompanyFacade();
			Collection<Coupon> coupon = companyFacade.getCouponsByDate(date);
			System.out.println("coupons ending before " + date);
			printCoupons(coupon);
		} catch (Exception e) {
			throw new CouponException("Check print coupons by date" + e.toString());

		}
	}
	/**
	 * PRINT COUPONS BY PRICE
	 * @param price
	 */
	private void printCouponsByPrice(long price) {
		try {
			CompanyFacade companyFacade = new CompanyFacade();

			Collection<Coupon> coupon = companyFacade.getCouponsByPrice(price);
			System.out.println("coupons cheaper then " + price);
			printCoupons(coupon);
		} catch (Exception e) {
			logger.error("printCouponsByPrice  failed : " + e.toString());

		}
	}
	/**
	 * PRINT COUPONS BY TYPE
	 * @param type
	 */
	private void printCouponsByType(CouponType type) {
		try {
			CompanyFacade companyFacade = new CompanyFacade();

			Collection<Coupon> coupon = companyFacade.getCouponByType(type);
			System.out.println("coupons type " + type);
			printCoupons(coupon);
		} catch (Exception e) {
			logger.error("printCouponsByType  failed : " + e.toString());

		}

	}
	/**
	 * print companies
	 */
	private void printCompany() {
		try {
			CompanyFacade companyFacade = new CompanyFacade();
			Company company = companyFacade.getCompany();
			logger.debug(company + " num coupons = " + company.getCoupons().size());
			printCoupons(company.getCoupons(), "\t");
		} catch (Exception e) {
			logger.error("printCompany failed : " + e.toString());
		}
	}
	/**
	 * create coupons
	 * @return
	 * @throws SQLException 
	 * @throws CompanyException 
	 * @throws activationException 
	 * @throws CouponException 
	 */
	public void createCoupon(Coupon coupon) throws CouponException, activationException, CompanyException, SQLException {
		try{
			CompanyFacade companyFacade = new CompanyFacade();
			companyFacade.createCoupon(coupon);
		}
		catch (Exception e) {
			e.printStackTrace();	
			}

	}
	/**
	 * UPDATE COUPONS
	 * @param couponID
	 */
	private void updateCoupon(long ID) {
		System.out.println("updating coupon with id : " + ID);
		try {
			CompanyFacade companyFacade = new CompanyFacade();
			Coupon coupon = companyFacade.getCouponByID(ID);
			coupon.setAmount(100);
			coupon.setPrice(coupon.getPrice() / 2);
			companyFacade.updateCoupon(coupon);
		} catch (Exception e) {
			logger.error("updateCoupon failed : " + e.toString());
		}
	}
	/**
	 * remove coupon
	 * @param couponID
	 */
	private void removeCoupon(long couponID) {
		System.out.println("removing coupon with id : " + couponID);
		try {
			CompanyFacade companyFacade = new CompanyFacade();

			companyFacade.removeCoupon(couponID);
		} catch (Exception e) {
			logger.error("removeCoupon failed : " + e.toString());
		}
	}
	/**
	 * expired daily coupon
	 * @param ID
	 */
	@SuppressWarnings("unused")
	private void expireCoupon(long ID) {
		System.out.println("expiering coupon with id : " + ID);

		try {
			CompanyFacade companyFacade = new CompanyFacade();

			Coupon coupon = companyFacade.getCouponByID(ID);
			coupon.setEndDate(LocalDate.now()); 
			companyFacade.updateCoupon(coupon);
		} catch (Exception e) {
			logger.error("expireCoupon failed : " + e.toString());
		}
	}

}

