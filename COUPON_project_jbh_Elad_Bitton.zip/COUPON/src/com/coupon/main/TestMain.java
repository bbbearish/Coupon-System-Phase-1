package com.coupon.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.coupon.connectionPool.ConnectionPool;
import com.coupon.couponSystem.CouponSystem;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.LoginException;
import com.coupon.exceptions.CouponProjectException.activationException;
import com.coupon.facade.AdminFacade;
import com.coupon.facade.CompanyFacade;
import com.coupon.facade.CouponClientFacade;
import com.coupon.facade.CustomerFacade;
import com.coupon.facade.TypeOfUser;
import com.coupon.util.LogUtils;
import com.coupon.util.Utils;

public class TestMain {

	static Logger logger = Logger.getLogger(TestMain.class);
	static CouponSystem couponSystem;
	static AdminFacade adminFacade;

	Connection myConn;
	PreparedStatement myPstat;
	ResultSet myRset;
	Statement myStat;
	static ConnectionPool CP;

	public static void main(String[] args) throws activationException, CompanyException, CouponException, CustomerException, InterruptedException, SQLException, LoginException {
		LogUtils.initLogger(); 
		
		printHeader("starting tests");
		try {
			@SuppressWarnings("unused")
			Connection myConn =ConnectionPool.getInstance().getConnection();
			couponSystem = CouponSystem.getInstance();
			couponSystem.setDailyTaskSleepTime(1 * Utils.MINUTE);

		
			printHeader("Deleting all records");
//			DELETE ALL DB
			deleteAll(); 
			
			/**
			 * ADMIN TEST
			 */
			printHeader("Teseting the AdminFacade");
			AdminFacade.login("admin", "1234", TypeOfUser.ADMIN);
			TestAdmin testAdmin = new TestAdmin();
			testAdmin.testCouponSystem();
			
			printHeader("Teseting the CompanyFacade");
			@SuppressWarnings("unused")
			CouponClientFacade clientFacade = new CompanyFacade();
			/**
			 * TEST COMPANY
			 */
			clientFacade =  couponSystem.login("sskjkdsk@gmil.com", "dsds99djks99", TypeOfUser.COMPANY);
			logger.info("company login with new password is ok");
			TestCompany testCompany = new TestCompany();
			testCompany.test();
			/**
			 * TEST CUSTOMER
			 */
			printHeader("Teseting the CustomerFacade");
			@SuppressWarnings("unused")
			CouponClientFacade customerFacade= new CustomerFacade();
			customerFacade =  couponSystem.login("elad@gmail.com", "ffdfdf", TypeOfUser.CUSTOMER);
			logger.info("customer " + "elad" + " login ok");
			TestCustomer testCustomer = new TestCustomer();
			testCustomer.test();

			/**
			 *  waiting two minutes to allow the daily task to do some work and then shut down
			 */
			printHeader("Shutting down");
			System.out.println("Shutting down in 2 min, please wait");
			Thread.sleep(2 * Utils.MINUTE); 
			couponSystem.shutdown();
			printHeader("All done");


		} catch (Exception e) {
			logger.error("TestMain failed : " + e.toString());
			e.printStackTrace();
			return;
		}

	}
	/**
	 * PRINT HEADERS
	 * @param text
	 */
	public static void printHeader(String text) {
		System.out.println("*********************BEARIS COUPON SYSTEM*******************");
		System.out.println(text);
		System.out.println("*****BEARIS COUPON SYSTEM***********END***TESTING***********");
	}

	/**
	 * createDataBase - creates the database tables from the scrapbook file
	 * @throws activationException 
	 */
	public static void createDataBase() throws activationException {
		System.out.println("Creating the database");
		Connection myConn =ConnectionPool.getInstance().getConnection();

		try {

			Utils.executeSqlScript(myConn, "scrapbook.sql");
		} catch (Exception e) {
			logger.error("createDataBase failed : " + e.toString());
			return;
		} finally {
			try {
				ConnectionPool.getInstance().returnConnection(myConn);
			} catch (Exception e) {
			}
		}
		System.out.println("Creating the database done");

	}

	/**
	 * delete all the records
	 * @throws activationException 
	 */
	public static void deleteAll() throws activationException {
		System.out.println("Emptying the database");

		Connection myConn =ConnectionPool.getInstance().getConnection();
		try {
	
			Utils.executeSqlCommand(myConn,"DELETE from customer_coupon");
			Utils.executeSqlCommand(myConn,"DELETE from company_coupon");
			Utils.executeSqlCommand(myConn,"DELETE from coupon");
			Utils.executeSqlCommand(myConn,"DELETE from company");
			Utils.executeSqlCommand(myConn,"DELETE from customer");
		} catch (Exception e) {
			logger.error("delete failed " + e.toString());
			return;
		} finally {
			try {
				ConnectionPool.getInstance().returnConnection(myConn);
			} catch (Exception e) {
			}
		}
		System.out.println("database Empty");		
	}


}
