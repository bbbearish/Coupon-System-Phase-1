package com.coupon.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.*;

import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;

import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;
/**
 * INTERFACE FOR ALL THE  COUPONS  FROM SQL
 * 
 */
public interface CouponDao {
	public void	createCoupon(Coupon coupon)throws CouponException, SQLException, activationException;
	public void	removeCoupon(long ID)throws CouponException, SQLException, activationException;
	public void updateCoupon(Coupon coupon)throws CouponException, SQLException, activationException;
	public Coupon getCoupon(long ID) throws CouponException, activationException, SQLException ;
	public ArrayList<Coupon> getAllCoupon() throws CouponException, SQLException, activationException;
	public ArrayList<Coupon> getCopounByType(CouponType type)throws  SQLException, CouponProjectException;
	public Coupon getFromResultSet(ResultSet myRset) throws SQLException, CouponException;
	public boolean isCoupon(long ID) throws CouponException, activationException;
	public ArrayList<Coupon> getCouponByMaxPrice(Company company, double price) throws CouponException, CouponProjectException, SQLException;
	public ArrayList<Coupon> getCouponByLateDate(Company company, LocalDate endDate) throws CouponException, CouponProjectException, SQLException;
	public void removeCoupon(Coupon coupon);
	public void getCouponByTitle(String couponTitle) throws CouponException, activationException;


}


