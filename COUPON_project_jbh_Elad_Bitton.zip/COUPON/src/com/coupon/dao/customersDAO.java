package com.coupon.dao;
import java.util.HashSet;
import com.coupon.basic.Customer;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.activationException;
/**
 * INTERFACE FOR ALL THE CUSTOMERS FROM SQL
 *  
 */

public interface customersDAO {

			public void createCustomer(Customer customer)throws CustomerException, activationException;	
			public void updateCustomer(Customer customer)throws CustomerException, activationException ;
			public HashSet<Customer> getAllCustomer()throws CustomerException, activationException ;
			public boolean login(String custName ,String password)throws CustomerException, activationException ;
			public Customer getCustomerByID(long ID) throws CustomerException, activationException ;
			public boolean isCustomer(long custName) throws CustomerException , activationException;
			public Customer getCustomerByName(String name) throws CustomerException, activationException ;
			public boolean isCustomerEmail(String Email) throws CustomerException , activationException;
			public void removeCustomer(long ID) throws CustomerException, activationException;

}
	
	
	
