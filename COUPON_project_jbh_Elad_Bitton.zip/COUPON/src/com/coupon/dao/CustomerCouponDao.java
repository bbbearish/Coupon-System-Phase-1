package com.coupon.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;

import com.coupon.DBDAO.CouponDBDAO;
import com.coupon.DBDAO.CustomerDBDAO;
import com.coupon.basic.Coupon;
import com.coupon.basic.CouponType;
import com.coupon.basic.Customer;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.CustomerException;
import com.coupon.exceptions.CouponProjectException.activationException;

/**
 * INTERFACE FOR THE CUSTOMER HOWS BUY COUPONS
 * @author Elad
 *
 */
public interface CustomerCouponDao {

	public HashSet<Coupon> getCouponsByType(CustomerDBDAO customer) throws CustomerException , activationException, CouponException, Exception, SQLException ;
	public boolean IsBought(CustomerDBDAO customer, CouponDBDAO coupon) throws CustomerException, activationException, CouponException, SQLException ;
	public void addCustomerCoupon(long customer, long coupon) throws CustomerException , activationException, CouponException, SQLException ;
	public void removeCustomerCoupon(CouponDBDAO coupon) throws CustomerException, activationException, CouponException, SQLException  ;
	public void removeCustomerCoupon(long ID) throws CustomerException , activationException, SQLException  ;
	public HashSet<Coupon> getCoupons(CustomerDBDAO customer) throws SQLException, activationException, CustomerException;
	public ArrayList<Coupon> getAllPurchasedCustomerCouponsByPrice(Customer customer,Coupon price) throws CouponProjectException, SQLException;
	public ArrayList<Coupon> getAllPurchasedCustomerCouponsByType(Customer customer ,CouponType type) throws CouponProjectException, SQLException;


}
