package com.coupon.dao;

import java.sql.SQLException;
import java.util.Set;

import com.coupon.basic.Company;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;
/**
 * INTERFACE FOR ALL THE COMPANYS FROM SQL
 */

public interface CompanyDAO {

	public void createCompany(Company company) throws CompanyException, activationException ;
	public void removeCompany(long companyID)throws CompanyException, activationException, CouponException;
	public void updateCompany(Company company) throws CompanyException, activationException, SQLException;
	public Company getCompanyByID(long ID) throws CompanyException, activationException;
	public Set<Company> getAllCompanys ()throws CompanyException, activationException;
	public boolean login(String email, String password) throws CompanyException, activationException;
	public boolean isCompany(long compID) throws CompanyException, activationException;
	public boolean isCompanyEmail(String Email) throws CompanyException, activationException;
	public Company getCompanyByName(String name) throws CompanyException, activationException ;
	public void removeCompany(Company company) throws SQLException, CompanyException, activationException, CouponException;
	public Company getCompanyByEmail(String name) throws CompanyException, activationException ;

}


