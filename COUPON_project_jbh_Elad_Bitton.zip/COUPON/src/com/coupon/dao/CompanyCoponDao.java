package com.coupon.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import com.coupon.basic.Company;
import com.coupon.basic.Coupon;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CompanyException;
import com.coupon.exceptions.CouponProjectException.CouponException;
import com.coupon.exceptions.CouponProjectException.activationException;
/**
 * INTERFACE THAT MAKE THE CONNECTION BETWEEN THE DB AND THE COUPONS
 * @author Elad
 *
 */
public interface CompanyCoponDao {

	public Collection<Coupon> getCoupons(long companyID) throws CompanyException, SQLException, activationException, CouponException;
	public void addCompanyCoupon(long companyID, long couponID) throws CompanyException, activationException, SQLException, CouponException;
	public void removeCompanyCoupon(long ID) throws CompanyException, activationException, CouponException;
	public void DeleteAllCompanyCoupons(long companyID) throws CompanyException, activationException;
	public ArrayList<Coupon> getCompanyCoupons(Company company)throws CouponException, CouponProjectException, SQLException ;
	public Collection<Long> GetAllCompanyCoupons(long companyID) throws CouponException, activationException ;
}
