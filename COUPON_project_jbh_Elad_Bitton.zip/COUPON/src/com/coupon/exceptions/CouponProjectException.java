package com.coupon.exceptions;

@SuppressWarnings("serial")
public class CouponProjectException extends Exception {
	/**
	 * Top Level Exception
	 * @param message
	 */
	public CouponProjectException(String message) {
		super(message);
	}
	/**
	 * Coupon Exception
	 * @author Elad
	 *
	 */
	public static class CouponException extends CouponProjectException {
		public CouponException(String message) {
			super(message);
		}
	}
	/**
	 * Company Coupon Exception
	 * @author Elad
	 *
	 */
	public static class CompanyCouponException extends CouponProjectException {
		public CompanyCouponException(String message) {
			super(message);
		}
	}
	/**
	 * Customer Coupon Exception
	 * @author Elad
	 *
	 */
	public static class CustomerCouponException extends CouponProjectException {
		public CustomerCouponException(String message) {
			super(message);
		}
	}
	/**
	 * Company Exception
	 * @author Elad
	 *
	 */
	public static class CompanyException extends CouponProjectException {
		public CompanyException(String message) {
			super(message);
		}
	}
	/**
	 * Customer Exception
	 * @author Elad
	 *
	 */
	public static class CustomerException extends CouponProjectException {
		public CustomerException(String message) {
			super(message);
		}
	}
	/**
	 * Login Exception
	 * For Customers and Companies
	 * @author Elad
	 *
	 */
	public static class LoginException extends CouponProjectException {
		public LoginException(String message) {
			super(message);
		}
	}
	/**
	 * Access Login Exception
	 * @author Elad
	 *
	 */
	public static class AccessForbiddenException extends LoginException {
		public AccessForbiddenException(String message) {
			super(message);
		}
	}
	/**
	 * Admin Login Exception
	 * @author Elad
	 *
	 */
	public static class AdminLoginException extends LoginException {
		public AdminLoginException(String message) {
			super(message);
		}

	}
	/**
	 * Company Login Exception
	 * @author Elad
	 *
	 */
	public static class CompanyLoginException extends LoginException {
		public CompanyLoginException(String message) {
			super(message);
		}
	}
	/**
	 * Customer Login Exception 
	 */
	public static class CustomerLoginException extends LoginException {
		public CustomerLoginException(String message) {
			super(message);
		}
	}
	/**
	 * Activation Exception
	 * @author Elad
	 *
	 */
	public static class activationException extends CouponProjectException{
		public activationException(String message) {
			super(message);
		}
		/**
		 * Check The Connection To The DB Exception
		 * @return
		 * @throws CouponProjectException
		 */
		public String connectivity() throws CouponProjectException{
			throw new CouponProjectException.AccessForbiddenException
			("connection to the DB lost. please try again");
		}
		/**
		 * Throw When Connection In Use
		 * @return
		 * @throws CouponProjectException
		 */
		public String ConnectionInUse() throws CouponProjectException{
			throw new CouponProjectException.AccessForbiddenException
			("connection in use. please try again later ");
		}


	}
}
