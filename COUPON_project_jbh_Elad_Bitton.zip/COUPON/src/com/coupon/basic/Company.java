package com.coupon.basic;

import com.coupon.exceptions.CouponProjectException.CompanyException;

import java.util.Collection;

import org.apache.commons.validator.routines.EmailValidator;
public class Company {

	/**
	 * ATTRIBUTES
	 * */
	private long ID ;
	private String compName;
	private String password;
	private String email;
	private Collection<Coupon> coupons;
	/**
	 * CONSTRUCTORS
	 * @throws CompanyException 
	 */
	public Company(){
		
	}
	
	public Company( String compName,String password,String email) throws CompanyException{
		setCompName(compName);
		setPassword(password);
		setEmail(email);
		getCoupons();
		
	}
	
	/**
	 * GETTERS
	 * */
	public long getID() {
		return ID;
	}
	public String getCompName() {
		return compName;
	}
	public String getPassword() {
		return password;
	}
	public String getEmail() {
		return email;
	}
	/**
	 * SETTERS
	 * @throws CompanyException 
	 * */
	public void setID(long ID) throws CompanyException {
		this.ID = ID;
	}
	public void setCompName(String compName) throws CompanyException {
			this.compName = compName;
	}
	public void setPassword(String password) throws CompanyException {
			this.password = password;
	}
	public void setEmail(String email) throws CompanyException{
		EmailValidator emailvalidator = EmailValidator.getInstance();
		if(emailvalidator.isValid(email)) {
			this.email=email;
		} else {
			throw new CompanyException("Email is invalid");
		}
		this.email = email;
	}
	/**
	 * 
	 * @return get and set coupons
	 */
	public Collection<Coupon> getCoupons() {
		return coupons;
	}

	public void setCoupons(Collection<Coupon> coupons) {
		this.coupons = coupons;
	}

	/**
	 * TO STRING 
	 * */

	@Override
	public String toString() {
		return "Company [ID=" + ID + ", compName=" + compName + ", password="
				+ password + ", email=" + email + ", coupons="  + "]";
	}

	/**
	 * METHOD TO COMPARE BETWEEN THE COMPANYS
	 * */

	public boolean equals(Object company){
		try{
			if(company instanceof Company)
				if(this.getID()==((Company)company).getID())
					return true;
			return false;
		}finally{
		}
	}
}
