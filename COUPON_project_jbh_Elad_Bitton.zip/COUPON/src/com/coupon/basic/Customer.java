package com.coupon.basic;


import java.util.ArrayList;

import org.apache.commons.validator.routines.EmailValidator;

import com.coupon.exceptions.CouponProjectException.CustomerException;

public class Customer {
	/**
	 * ARRRIBUTES	
	 */
	private long ID;
	private String custName;
	private String password;
	private String email;
	private ArrayList<Coupon> coupons;

	/**
	 * CONSTRUCTORS	
	 */
	public Customer(){}

	public Customer
	(String custName,String password,String email) throws CustomerException{
		setCustName(custName);
		setPassword(password);
		setEmail(email);
		coupons = new ArrayList<Coupon>();
	}
	/**
	 * GETTERS	
	 */
	public long getID() {
		return ID;
	}
	public String getCustName() {
		return custName;
	}
	public String getPassword() {
		return password;
	}

	public String getEmail() {
		return email;
	}

	/**
	 * SETTERS	
	 * @throws CouponProjectException 
	 */
	public void setID(long ID) throws CustomerException {
		if(ID > 0){
			this.ID = ID;
		}else if (this.ID==ID){
			throw new CustomerException("The ID Already Exist");
		}else {
			throw new  CustomerException("The ID less then zero");
		}
	}

	public void setCustName(String custName) throws CustomerException {
		if(custName.equals(null)){
			throw new  CustomerException("YOU NEED TO INSERT YOUR NAME");
		}else if(custName.isEmpty()){
			throw new  CustomerException("YOU NEED TO INSERT YOUR NAME");
		}else if(custName.equals(" ")){
			throw new  CustomerException("YOU NEED TO INSERT YOUR NAME");
		}else{
			this.custName = custName;
		}
	}

	public void setPassword(String password) throws CustomerException {
		if(!(password.equals(null))){
			this.password = password;
		}else{
			throw new  CustomerException("YOU NEED TO INSERT PASSWORD");
		}
	}

	public void setEmail(String email) throws CustomerException {
		EmailValidator emailvalidator = EmailValidator.getInstance();
		if(emailvalidator.isValid(email)) {
			this.email=email;
		} else {
			throw new  CustomerException("Email is invalid");
		}
	}
	/**
	 * 
	 * @return get and set coupons
	 */
	public ArrayList<Coupon> getCoupons() {
		return coupons;
	}

	public void setCoupons(ArrayList<Coupon> coupons) {
		this.coupons = coupons;
	}
	/**
	 * TO STRING 
	 * */

	@Override
	public String toString() {
		return "customers [ID=" + ID + ", custName=" + custName + ", password="
				+ password + ", email=" + email + "]";
	}

	/**
	 * METHOD TO COMPARE BETWEEN THE CUSTOMERS	
	 */	
	public boolean equals(Object customer){
		if(customer instanceof Customer)
			if(this.getID()==((Customer)customer).getID())
				return true;
		return false;
	}

}
