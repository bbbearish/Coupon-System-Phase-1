package com.coupon.basic;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import com.coupon.exceptions.CouponProjectException;
import com.coupon.exceptions.CouponProjectException.CouponException;

public class Coupon {
	/**
	 * ATTRIBUTES
	 */
	private long ID ;
	private String title;
	private LocalDate startDate;
	private LocalTime startTime;
	private LocalDate endDate;
	private LocalTime endTime;
	private int amount;
	private CouponType CouponType;
	private String message;
	private double price;
	private String image;


	/**
	 * CONSTRUCTOR
	 */
	public Coupon(){}

	public Coupon(String title,LocalDate startDate,LocalTime startTime
			,LocalDate endDate,LocalTime endTime ,int amount,CouponType CouponType,String message
			,double price,String image) throws CouponProjectException{
	
		setTitle(title);
		setStartDate(startDate);
		setStartTime(startTime);
		setEndDate(endDate);
		setEndTime(endTime);
		setAmount(amount);
		setCouponType(CouponType);
		setMessage(message);
		setPrice(price);
		setImage(image);
	}

	/**
	 * GETTERS
	 */
	public long getID() {
		return ID;
	}
	public String getTitle() {
		return title;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public LocalTime getStartTime() {
		return startTime;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public LocalTime getEndTime() {
		return endTime;
	}
	public int getAmount() {
		return amount;
	}
	public CouponType getType() {
		return CouponType;
	}
	public String getMessage() {
		return message;
	}
	public double getPrice() {
		return price;
	}
	public String getImage() {
		return image;
	}

	/**
	 * SETTERS
	 * @throws CouponException 
	 */
	public void setID(long ID) throws CouponException {
		if(ID > 0){
			this.ID = ID;
		}else if (this.ID==ID){
			throw new CouponException("The ID Already Exist");
		}else {
			throw new CouponException("The ID less then zero");
		}
	}
	public void setTitle(String title) throws CouponException {
		if (title.equals(null)){
			throw new CouponException("coupon is null...check again");
		}else if (title.equals(" ")){		
			throw new CouponException("coupon is empty ...check again");
		}else{
			this.title = title;
		}
	}
	public void setStartDate(LocalDate startDate) throws CouponException {
		if (startDate.equals(null)){
			throw new CouponException("START DATE CAN'T BE NULL");
		}else if(startDate.equals(" ")){
			throw new CouponException("START DATE CAN'T BE EMPTY");
		}else if(startDate.equals(LocalDateTime.now())){
			throw new CouponException("YOU NEED TO SET TIME THAT NOT PAST TO CREATE THE COUPON ");
		}else{
			this.startDate = startDate;
		}
	}
	public void setStartTime(LocalTime startTime) throws CouponException {
		if (startTime.equals(null)){
			throw new CouponException("START TIME CAN'T BE NULL");
		}else if(startTime.equals(" ")){
			throw new CouponException("START TIME CAN'T BE EMPTY");
		}else if(startDate.equals(LocalTime.now())){
			throw new CouponException("YOU NEED TO SET TIME THAT NOT PAST TO CREATE THE COUPON ");
		}else{
			this.startTime = startTime;
		}
	}
	public void setEndDate(LocalDate endDate)throws CouponException {
		if(!(endDate.isBefore(startDate))){
			this.endDate = endDate;
		}else{
			throw new CouponException("THE END TIME OF THE COUPON CANNOT BE LESS THE START COUPON TIME");
		}
	}
	public void setEndTime(LocalTime endTime) throws CouponException {
		if(!(endTime.isBefore(startTime))){
			this.endTime = endTime;
		}else{
			throw new CouponException("THE END TIME OF THE COUPON CANNOT BE LESS THE START COUPON TIME");
		}
	}
	public void setAmount(int amount) throws CouponException {
		if(amount >= 0 ){
			this.amount = amount;
		}else{
			throw new CouponException("AMOUNT CAN'T BE LESS THEN ZERO");
		}
	}
	public void setCouponType(CouponType CouponType) {
		this.CouponType = CouponType;
	}
	public void setMessage(String message) throws CouponException {
		if (title.equals(null) || title.equals(" ")){
			throw new CouponException("YOU NEED TO ADD DESCRIPTION TO THE COUPON");
		}else
			this.message = message;
	}
	public void setPrice(double price) throws CouponException {
		if(price > 0){
			this.price = price;
		}else {
			throw new CouponException("The price canot be less then zero");
		}
	}
	public void setImage(String image) throws CouponException {
		if(!(image.equals(null))){
			this.image = image;
		}else{
			throw new CouponException("image not exist ");
		}
	}

	/**
	 * TO STRING 
	 * */

	@Override
	public String toString() {
		return "Coupon [ID=" + ID + ", title=" + title + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", amount=" + amount + ", type=" + CouponType + ", message=" + message + ", price=" + price + ", image="
				+ image + "]";
	}
	/**
	 * METHOD to compare between the coupons
	 */
	public boolean equals(Object coupon){
		if(coupon instanceof Coupon)
			if(this.getID()==((Coupon)coupon).getID())
				return true;
		return false;
	}

	/**
	 * checks if the coupon is expired.
		
	 * @return - true if endDate is before the current date
	 */
	public boolean isExpired() {
		return endDate.isBefore(LocalDate.now());
	}
}
