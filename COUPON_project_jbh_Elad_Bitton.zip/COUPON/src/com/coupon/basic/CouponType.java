package com.coupon.basic;

public enum CouponType {

/**CATEGORYS FOR THE
 *  COUPON SITE*/
	
	RESTURANT,ELECTRICITY
	,FOOD,HEALTH,SPORTS,CAMPING,TRAVELLING, GADJETS;
}





