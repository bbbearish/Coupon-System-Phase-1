package com.coupon.connectionPool;

import java.sql.*;
import java.util.*;
import org.apache.log4j.Logger;
import com.coupon.exceptions.CouponProjectException.activationException;

/**
 *THIS SINGELTON CLASS DEFINE THE CONNECTIONS FROM/TO THE DATA BASE 
 *START AND KILL PROCCESS ...
 */
public class ConnectionPool {
	/**
	 *attributes:
	 *THE CONNECTION POOL TO THE DB
	 */
	private static ConnectionPool myConn;
	/**
	 *HOW MUCH CONNECTIONS CAN BE 
	 * 
	 */
	private static int userConnection=10;
	/**
	 * CREATE POOL CONNECTIONS BETWEEN THE DB TO THE USERS
	 * 
	 */
	private ArrayList<Connection> poolConnections
	= new ArrayList<>();

	/**
	 * log4j for debugging the coupon system
	 */
	static Logger logger = Logger.getLogger(ConnectionPool.class);
	/** 
	 *  a singleton method creating an instance of the connection-pool:
	 * return connectionPool
	 * 
	 * @return
	 * @throws CouponExceptions
	 */
	/**
	 * getInstance method belong to singleton
	 * 
	 * @return
	 * @throws activationException
	 */
	public static ConnectionPool getInstance() throws activationException {
		if(myConn==null)
			myConn=new ConnectionPool();
		return myConn;
	}
	/**
	 * CONNECT TO THE DATA BASE 
	 * 
	 * @throws activationException
	 */
	public ConnectionPool() throws activationException {
		try{
			for(int i=0;i<userConnection;i++)
				poolConnections.add(DriverManager.getConnection
						("jdbc:mysql://localhost:3306/coupon?useSSL=false","root","1911"));
		}catch(Exception e){
			logger.debug ("CONNECTION FAILD!!! - PLEASE CHACK AGAIN THE CONNECTION TO THE DATABASE");
		}
	}
	/**
	 * ENABLE THE CONNECTION POOL TO THE DBDAO CLASSES
	 * @return
	 * @throws activationException 
	 */
	public synchronized Connection getConnection() throws activationException  { 
		Connection setConnection;
		while(poolConnections.size()==0)
			try {
				this.wait();
			} catch (InterruptedException e) {
				logger.debug("THE CONNECTION TO THE DB IS BUSY...TRY AGAIN");
			}
		setConnection=poolConnections.get(0);
		poolConnections.remove(0);
		return setConnection;
	}
	/**
	 * WE MAKE A SYNCHRONIZED FUNCTION TO KEEP ALIVE THE CONNECTION
	 * THE NOTIFI SHUOLD BE WAKE UP THE WAITING PROCCESSES
	 * 
	 * @param connection
	 * throws activationException
	 */
	public synchronized void returnConnection(Connection connection)throws activationException{
		this.poolConnections.add(connection);
		if(this.poolConnections.size()==1)
			this.notify();
	}
	/**
	 * KILL ALL THE CONNECTIONS 
	 * @throws activationException
	 */
	public void closeAllConnections() throws activationException{
		while(poolConnections.size()>0){
			try {
				poolConnections.get(0).close();
			} catch (SQLException e) {
				throw new activationException("CONNECTION CLOSE, BAY BAY ");
			}
			poolConnections.remove(0);
		}
	}
}